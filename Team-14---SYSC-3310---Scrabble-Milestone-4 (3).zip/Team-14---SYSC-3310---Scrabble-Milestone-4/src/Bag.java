import java.io.Serializable;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

/**
 * A class representing a bag holding tiles in the game of scrabble.
 *
 * @author Kyle Foisy, Peter McComb
 * @version Nov 26
 */
public class Bag implements Serializable {
    private List<Tile> tiles;

    /**
     * A constructor for the bag that holds all the tiles in scrabble.
     */
    public Bag() {
        tiles = new ArrayList<Tile>();
        for (int i = 0; i < 9; i++) {
            tiles.add(new Tile('A'));
        }
        for (int i = 0; i < 2; i++) {
            tiles.add(new Tile('B'));
        }
        for (int i = 0; i < 2; i++) {
            tiles.add(new Tile('C'));
        }
        for (int i = 0; i < 4; i++) {
            tiles.add(new Tile('D'));
        }
        for (int i = 0; i < 12; i++) {
            tiles.add(new Tile('E'));
        }
        for (int i = 0; i < 2; i++) {
            tiles.add(new Tile('F'));
        }
        for (int i = 0; i < 3; i++) {
            tiles.add(new Tile('G'));
        }
        for (int i = 0; i < 2; i++) {
            tiles.add(new Tile('H'));
        }
        for (int i = 0; i < 9; i++) {
            tiles.add(new Tile('I'));
        }
        tiles.add(new Tile('J'));
        tiles.add(new Tile('K'));
        for (int i = 0; i < 4; i++) {
            tiles.add(new Tile('L'));
        }
        for (int i = 0; i < 2; i++) {
            tiles.add(new Tile('M'));
        }
        for (int i = 0; i < 6; i++) {
            tiles.add(new Tile('N'));
        }
        for (int i = 0; i < 8; i++) {
            tiles.add(new Tile('O'));
        }
        for (int i = 0; i < 2; i++) {
            tiles.add(new Tile('P'));
        }
        tiles.add(new Tile('Q'));
        for (int i = 0; i < 6; i++) {
            tiles.add(new Tile('R'));
        }
        for (int i = 0; i < 4; i++) {
            tiles.add(new Tile('S'));
        }
        for (int i = 0; i < 6; i++) {
            tiles.add(new Tile('T'));
        }
        for (int i = 0; i < 4; i++) {
            tiles.add(new Tile('U'));
        }
        for (int i = 0; i < 2; i++) {
            tiles.add(new Tile('V'));
        }
        for (int i = 0; i < 2; i++) {
            tiles.add(new Tile('W'));
        }
        tiles.add(new Tile('X'));
        for (int i = 0; i < 2; i++) {
            tiles.add(new Tile('Y'));
        }
        tiles.add(new Tile('Z'));

        for (int i = 0; i < 2; i++) {
            tiles.add(new BlankTile());
        }
        shuffleBag();
    }

    /**
     * A method to randomize the order of the contents of the bag.
     */
    public void shuffleBag() {
        Collections.shuffle(tiles);
    }

    /**
     * Grabs a random tile from the bag.
     * Since bag is shuffled, removeFirst is random.
     * 
     * @return A tile from the bag
     */
    public Tile grabTile() {
        return tiles.removeFirst();
    }

    /**
     * Places a tile in the bag
     *
     * @param tile the tile to be added to the bag
     * @return True if the tile has been added to the bag
     */
    public void putTileInBag(Tile tile) {
        tiles.add(tile);
        shuffleBag();
    }

    /**
     * Returns the number of tiles left in the bag.
     *
     * @return The number of tiles in the bag
     */
    public int getNumTilesLeft() {
        return tiles.size();
    }

    /**
     * Creates a copy of the current Bag.
     *
     * @return A copy of the current Bag.
     */
    public Bag createCopy() {
        Bag newBag = new Bag();
        newBag.tiles = new ArrayList<>(); // empty constuctor bag

        for (Tile tile : this.tiles) {
            newBag.tiles.add(new Tile(tile.getLetter())); // fill with current state
        }

        return newBag;
    }
}
