import java.io.Serializable;

/**
 * A class representing a tile containing a letter and score in a game of
 * Scrabble.
 *
 * @author Kyle Foisy, Peter McComb
 * @version Oct 20
 */
public class Tile implements Serializable {
    protected char letter;
    protected int score;
    protected Boolean placed;

    /**
     * A constructor for a tile in scrabble.
     *
     * @param letter The letter located on the tile
     */
    public Tile(char letter) {
        char c = Character.toUpperCase(letter);
        this.letter = c;

        this.score = getLetterScore(c);
        this.placed = false;
    }

    /**
     * A helper function to score letters.
     *
     * @param c The letter located on the tile
     */
    public static int getLetterScore(char c) {
        if ("AEIOULNRST".indexOf(c) >= 0)
            return 1;
        else if ("DG".indexOf(c) >= 0)
            return 2;
        else if ("BCMP".indexOf(c) >= 0)
            return 3;
        else if ("FHVWY".indexOf(c) >= 0)
            return 4;
        else if ("K".indexOf(c) >= 0)
            return 5;
        else if ("JX".indexOf(c) >= 0)
            return 8;
        else if ("QZ".indexOf(c) >= 0)
            return 10;
        else
            return 0;
    }

    public char getLetter() {
        return letter;
    }

    public int getScore() {
        return score;
    }

    public void placeTile() {
        placed = true;
    }

    public Boolean isPlaced() {
        return placed;
    }

    public Boolean isBlank() {
        if (this.getClass().equals(BlankTile.class)) {
            return true;
        } else {
            return false;
        }
    }
}
