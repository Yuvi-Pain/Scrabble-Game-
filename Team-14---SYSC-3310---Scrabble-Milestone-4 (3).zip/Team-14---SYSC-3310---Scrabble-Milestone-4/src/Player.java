import java.io.Serializable;
import java.util.ArrayList;

import javax.swing.text.PlainDocument;

/**
 * A class representing a player in the game of scrabble.
 *
 * @author Kyle Foisy, Peter McComb
 * @version Oct 18th
 */
public class Player implements Serializable {
    private ArrayList<Tile> hand;
    private int score;
    private String name;

    /**
     * A constructor for a player who plays scrabble.
     *
     * @param playerName the name of the scrabble player
     */
    public Player(String playerName) {
        hand = new ArrayList<Tile>();
        score = 0;
        name = playerName;
    }

    /**
     * Adds a tile to the player's hand.
     *
     * @param tile the tile to be added to the player's hand
     */
    public void addTile(Tile tile) {
        hand.add(tile);
    }

    /**
     * Given a letter, removes the matching tile from the player's hand
     *
     * @param letter letter of the tile to be removed
     * @return the removed tile
     */
    public Tile removeTile(char letter) {
        for (int i = 0; i < hand.size(); i++) {
            if (hand.get(i).getLetter() == letter) {
                // found matching tile in hand
                return hand.remove(i);
            }
        }
        return null; // tile not found, nothing removed
    }

    /**
     * Given a tile, remove tile from player's hand
     */
    public void removeTile(Tile tile) {
        hand.remove(tile);
    }

    /**
     * Increases a player's score by a given value.
     *
     * @param value The value by which the player's score must increase
     */
    public void increaseScore(int value) {
        score += value;
    }

    /**
     * Decrease a player's score by a given value.
     *
     * @param value The value by which the player's score must decrease
     */
    public void decreaseScore(int value) {
        score -= value;
    }

    /**
     * Returns the current hand of the player.
     *
     * @Return The current hand of the player.
     */
    public ArrayList<Tile> getHand() {
        return hand;
    }

    /**
     * Returns the player's total score.
     *
     * @return This player's score.
     */
    public int getScore() {
        return score;
    }

    /**
     * Returns the player's name.
     *
     * @return This player's name.
     */
    public String getName() {
        return name;
    }

    /**
     * Determine if a tile exists in a player's hand using char.
     *
     * @param letter The letter of the tile.
     * @return a boolean indicating if the player has the tile.
     */
    public Boolean hasTile(char letter) {
        letter = Character.toUpperCase(letter);

        for (Tile tile : hand) {
            if (tile.letter == letter)
                return true; // has tile
        }

        return false; // does not have tile
    }

    /**
     * Determine if a tile exists in a player's hand using tile.
     *
     * @param targetTile The tile to check for.
     * @return a boolean indicating if the player has the tile.
     */
    public Boolean hasTile(Tile targetTile) {
        for (Tile tile : hand) {
            if (tile == targetTile)
                return true; // has tile
        }
        return false; // does not have tile
    }

    /**
     * Used to determine if a player has a list of tiles.
     *
     * @param tiles The tiles we want to check with player's hand.
     * @return a boolean indicating if the player has all specified tiles.
     */
    public Boolean hasTiles(ArrayList<Character> tiles) {
        ArrayList<Tile> temp = new ArrayList<>(); // Temporary remove tiles for handling duplicates
        for (char tileLetter : tiles) {
            if (!hasTile(tileLetter)) {
                hand.addAll(temp);
                return false;
            }
            temp.add(removeTile(tileLetter));// player does not possess tile
        }
        hand.addAll(temp);
        return true; // all tiles are valid
    }

    /**
     * Returns the number of tiles a player has.
     *
     * @return This player's number of tiles
     */

    public int tileCount() {
        return this.hand.size();
    }

    /**
     * Creates a copy of the current Player.
     *
     * @return A copy of the current Player.
     */
    public Player createCopy() {
        Player newPlayer = new Player(this.name);

        for (Tile tile : this.hand) {
            newPlayer.addTile(new Tile(tile.getLetter()));
        }

        newPlayer.score = this.score;

        return newPlayer;
    }

}
