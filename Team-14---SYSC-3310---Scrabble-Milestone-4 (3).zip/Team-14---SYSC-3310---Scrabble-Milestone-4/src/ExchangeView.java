import javax.swing.*;
import javax.swing.text.View;
import java.awt.*;
import java.util.ArrayList;

/**
 * Represents a popup window used by the player to select which tiles they would
 * like to exchange.
 *
 * @author Kyle Foisy
 */
public class ExchangeView extends JFrame {
    private ScrabbleModel model;
    private ExchangeController controller;
    private JButton[] buttons;

    /**
     * The constructor for this class.
     *
     * @param hand  The current player's hand
     * @param model The scrabble model
     */
    public ExchangeView(ArrayList<Tile> hand, ScrabbleModel model) {
        super("Exchange");
        controller = new ExchangeController(hand, model, this);
        this.setLayout(new BorderLayout());
        JLabel text = new JLabel("Select the tiles you wish to exchange");
        JPanel handPanel = new JPanel(new GridLayout(1, hand.size()));
        JPanel buttonPanel = new JPanel(new GridLayout(1, 2));

        // Configure buttons for tiles in player's hand
        buttons = new JButton[hand.size()];
        for (int i = 0; i < hand.size(); i++) {
            JButton button = new JButton();
            button.setText("<html>" + hand.get(i).getLetter() + "<br>" + hand.get(i).getScore());
            button.setBackground(new Color(0xE9D09E)); // wood brown
            button.setActionCommand(Integer.toString(i));
            button.addActionListener(controller);
            handPanel.add(button);
            buttons[i] = button;
            button.setVisible(true);
        }
        // Configure button to confirm selection
        JButton confirmButton = new JButton("Confirm");
        confirmButton.setActionCommand("confirm");
        confirmButton.addActionListener(controller);
        buttonPanel.add(confirmButton);
        confirmButton.setVisible(true);

        // Configure button to cancel exchanging tiles
        JButton cancelButton = new JButton("Cancel");
        cancelButton.setActionCommand("cancel");
        cancelButton.addActionListener(controller);
        cancelButton.setVisible(true);
        buttonPanel.add(cancelButton);

        this.add(text, BorderLayout.NORTH);
        this.add(handPanel, BorderLayout.CENTER);
        this.add(buttonPanel, BorderLayout.SOUTH);
        this.setSize(350, 130);
        this.setResizable(false);
        this.setLocation(500, 300);
        this.setVisible(true);
        this.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
    }

    /**
     * Changes the colour of the buttons depending on if they were selected.
     *
     * @param selected An array of booleans that specify if a button was selecet.
     *                 True if it was, false otherwise.
     */
    public void updateButtons(boolean[] selected) {
        for (int i = 0; i < selected.length; i++) {
            if (selected[i]) {
                buttons[i].setBackground(new Color(0x92B5D4)); // Light Blue
            } else {
                buttons[i].setBackground(new Color(0xE9D09E)); // wood brown
            }
        }
    }
}
