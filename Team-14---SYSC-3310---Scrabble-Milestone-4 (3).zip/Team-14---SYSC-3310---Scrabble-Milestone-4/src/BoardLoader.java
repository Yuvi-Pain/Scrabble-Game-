import org.json.JSONArray;
import org.json.JSONObject;
import org.json.JSONString;

import java.io.BufferedReader;
import java.io.FileInputStream;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.nio.charset.Charset;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.util.ArrayList;

/**
 * A utility class for loading Scrabble board configurations from a JSON file.
 * Author: Yuvraj Bains
 */
public class BoardLoader {
    /**
     * Loads the board configuration from a JSON file.
     *
     * @param filePath The path to the JSON file. If null, loads the default JSON
     *                 from resources.
     * @return A 2D array representing the board layout.
     * @throws Exception If the file cannot be read or parsed.
     */
    public static String[][] loadBoard(String filePath) throws Exception {
        if (filePath == null) {
            // Load default JSON file from resources (inside JAR)
            try (InputStream inputStream = BoardLoader.class.getResourceAsStream("/custom_board.json")) {
                if (inputStream == null) {
                    throw new IllegalArgumentException("Default JSON file not found in resources.");
                }
                filePath = new String(inputStream.readAllBytes());
            }
        }else{
            System.out.println(filePath);
            BufferedReader br = new BufferedReader(new InputStreamReader(new FileInputStream(filePath)));
            String line = " ";
            ArrayList<String> content = new ArrayList<>();
            while((line = br.readLine()) != null){
                if(line.equals("#END")) {
                    break;
                }
                else{
                    content.add(line);
                }
            }

            int rows = content.size();
            int cols = content.size();
            String[][] board = new String[rows][cols];
            for (int i = 0; i < rows; i++) {
                String[] rowItems = content.get(i).split(",");
                System.arraycopy(rowItems, 0, board[i], 0, cols);
            }
            return board;
        }
        return null;
    }
}
