import javax.swing.*;
import javax.swing.border.*;
import java.awt.*;
import java.lang.reflect.Array;
import java.util.*;

public class ScrabbleView extends JFrame {
    private ScrabbleModel model;
    private ScrabbleController controller;
    private JLabel scoreLabel;
    private JButton[][] grid;
    private JLabel curPlayer;
    private JLabel tilesLeft;
    private JButton[] handTiles;
    private JButton[] playerControls;
    private JMenuItem undo;
    private JMenuItem redo;

    public ScrabbleView() {
        super("Scrabble");

        // setup MVC
        model = new ScrabbleModel();
        model.addView(this);
        controller = new ScrabbleController(model, this);

        // setup game view
        initMenuBar();
        model.initPlayers();
        initScoreboard();
        initBoard();
        initGameState();
        initBottomControls(); // (hand/controls)

        this.setSize(1000, 1000);
        this.setLocationRelativeTo(null); // center
        this.setVisible(true);
        this.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);

        model.saveInitState(); // save empty board

        if (model.getCurPlayer() instanceof AIPlayer) {
            // handle AI getting first turn
            AITurn();
            ((AIPlayer) model.getCurPlayer()).handleTurn();
        }
    }

    /**
     * Sets up the menubar with undo/redo, save/load, and custom board
     */
    private void initMenuBar() {
        JMenuBar menuBar = new JMenuBar();
        JMenu gameMenu = new JMenu("Game");

        undo = new JMenuItem("Undo");
        redo = new JMenuItem("Redo");
        JMenuItem save = new JMenuItem("Save Game");
        JMenuItem load = new JMenuItem("Load Game");
        JMenuItem loadBoard = new JMenuItem("Load Custom Board");

        undo.setActionCommand("undo");
        undo.addActionListener(controller);
        undo.setEnabled(false);
        redo.setActionCommand("redo");
        redo.addActionListener(controller);
        redo.setEnabled(false);
        save.setActionCommand("save");
        save.addActionListener(controller);
        load.setActionCommand("load");
        load.addActionListener(controller);
        loadBoard.setActionCommand("loadBoard");
        loadBoard.addActionListener(controller);

        gameMenu.add(undo);
        gameMenu.add(redo);
        gameMenu.addSeparator();
        gameMenu.add(save);
        gameMenu.add(load);
        gameMenu.addSeparator();
        gameMenu.add(loadBoard);

        menuBar.add(gameMenu);
        this.setJMenuBar(menuBar);
    }

    /**
     * Sets up scoreboard
     */
    private void initScoreboard() {
        scoreLabel = new JLabel();
        scoreLabel.setText(getScoreString(model.getPlayers()));
        this.add(scoreLabel, BorderLayout.WEST);
    }

    /**
     * Sets up the board (board spaces and labels)
     */
    private void initBoard() {
        JPanel boardPanel = new JPanel(new GridLayout(15, 15));
        grid = new JButton[15][15];

        Board board = model.getBoard();
        for (int i = 0; i < 15; i++) {
            for (int j = 0; j < 15; j++) {
                JButton boardspace = new JButton();
                boardspace.addMouseListener(controller);
                boardspace.putClientProperty("type", "boardspace"); // type to differentiate from tiles on mouse events
                boardspace.putClientProperty("row", i); // row to be accessed on mouse event
                boardspace.putClientProperty("col", j); // col to be accessed on mouse event
                grid[i][j] = boardspace;
                boardspace.setPreferredSize(new Dimension(50, 50));
                boardPanel.add(boardspace);
            }
        }
        boardPanel.setPreferredSize(new Dimension(750, 750));
        this.add(boardPanel, BorderLayout.CENTER);

        updateBoard(board);
        boardPanel.setVisible(true);
    }

    /**
     * Sets up game status tracker
     */
    private void initGameState() {
        JPanel rightPanel = new JPanel(new GridLayout(2, 1));

        curPlayer = new JLabel("<html><u>Current turn:</u><br>" + model.getCurPlayer().getName() + "</html>");
        rightPanel.add(curPlayer);

        tilesLeft = new JLabel("<html><u>Number of tiles in bag:</u><br>" + model.getNumTilesLeft() + "</html>");
        rightPanel.add(tilesLeft);

        rightPanel.setVisible(true);
        this.add(rightPanel, BorderLayout.EAST);
    }

    /**
     * Sets up bottom user controls (active hand and buttons)
     */
    private void initBottomControls() {
        JPanel bottomContainer = new JPanel();
        bottomContainer.setLayout(new BoxLayout(bottomContainer, BoxLayout.Y_AXIS));
        bottomContainer.setPreferredSize(new Dimension(1000, 100));

        initHandPanel(bottomContainer);
        initControls(bottomContainer);

        this.add(bottomContainer, BorderLayout.SOUTH);
    }

    /**
     * Sets up the hand panel
     */
    private void initHandPanel(JPanel container) {
        // init hand tiles
        JPanel handPanel = new JPanel(new FlowLayout(FlowLayout.CENTER, 10, 0));
        handTiles = new JButton[7];

        for (int i = 0; i < handTiles.length; i++) {
            JButton tile = new JButton();
            tile.addMouseListener(controller);
            tile.putClientProperty("type", "tile"); // type to differentiate from boardspaces on mouse events
            tile.setBackground(new Color(0xE9D09E)); // wood brown
            tile.setPreferredSize(new Dimension(50, 50));
            handTiles[i] = tile;
            handPanel.add(tile);
        }
        updateHand(model.getCurPlayer());

        handPanel.setVisible(true);
        container.add(handPanel);
    }

    /**
     * Sets up the controls
     */
    private void initControls(JPanel container) {
        // init player action buttons
        JPanel actionPanel = new JPanel(new FlowLayout(FlowLayout.CENTER, 10, 0));
        actionPanel.setAlignmentY(FlowLayout.CENTER);
        playerControls = new JButton[4];

        // confirm placements
        JButton confirmBtn = new JButton("Confirm Word");
        confirmBtn.setActionCommand("confirmWord");
        confirmBtn.addActionListener(controller);
        playerControls[0] = confirmBtn;
        actionPanel.add(confirmBtn);

        // remove placements
        JButton removeBtn = new JButton("Remove Placed Tiles");
        removeBtn.setActionCommand("removePlaced");
        removeBtn.addActionListener(controller);
        playerControls[1] = removeBtn;
        actionPanel.add(removeBtn);

        // exchange tiles
        JButton exchangeBtn = new JButton("Exchange Tiles");
        exchangeBtn.setActionCommand("exchangeTiles");
        exchangeBtn.addActionListener(controller);
        playerControls[2] = exchangeBtn;
        actionPanel.add(exchangeBtn);

        // skip turn
        JButton passBtn = new JButton("Pass Turn");
        passBtn.setActionCommand("passTurn");
        passBtn.addActionListener(controller);
        playerControls[3] = passBtn;
        actionPanel.add(passBtn);

        actionPanel.setVisible(true);
        container.add(actionPanel);
    }

    /**
     * Handles updates from the model
     */
    public void handleStatusUpdate(ScrabbleEvent e) {
        // RERENDER VIEW
        updateScoreboard(e.getPlayers());
        updateBoard(e.getBoard());
        updateGameState(e.getCurPlayer().getName(), e.getNumTiles());
        updateHand(e.getCurPlayer());
        updateMenuItems();

        // change view based on human/AI player or game over
        switch (e.getStatus()) {
            case ScrabbleModel.Status.PLAYING:
                playerTurn(e.getCurPlayer());
                break;
            case ScrabbleModel.Status.AI_TURN:
                AITurn();
                break;
            case ScrabbleModel.Status.GAME_OVER:
                gameOver(e.getPlayers());
                break;
        }
    }

    /**
     * Updates the scoreboard to represent the current game state
     */
    public void updateScoreboard(ArrayList<Player> players) {
        scoreLabel.setText(getScoreString(players));
    }

    /**
     * Updates the board to represent the current game state
     */
    public void updateBoard(Board board) {
        for (int i = 0; i < 15; i++) {
            for (int j = 0; j < 15; j++) {
                BoardSpace boardSpace = board.getBoardSpace(i, j);

                if (boardSpace.hasTile()) {
                    Tile tile = boardSpace.getTile();
                    grid[i][j].setText("<html>" + tile.getLetter() + "<br>" + tile.getScore() + "</html>");
                    grid[i][j].setBackground(new Color(0xE9D09E)); // wood brown

                    if (tile.isPlaced()) {
                        grid[i][j].setBorder(new LineBorder(Color.WHITE, 1)); // white outline
                    } else {
                        grid[i][j].setBorder(new LineBorder(Color.BLACK, 1)); // black outline
                    }
                } else {
                    switch (boardSpace.getModifier()) {
                        case NONE -> {
                            grid[i][j].setText("");
                            grid[i][j].setBackground(new Color(0xECE8E0)); // beige
                        }
                        case LS2X -> {
                            grid[i][j].setText("<html>Double<br>Letter<br>Score</html>");
                            grid[i][j].setBackground(new Color(0x92B5D4)); // light blue
                        }
                        case LS3X -> {
                            grid[i][j].setText("<html>Triple<br>Letter<br>Score</html>");
                            grid[i][j].setBackground(new Color(0x4B76C1)); // blue
                        }
                        case WS2X -> {
                            grid[i][j].setText("<html>Double<br>Word<br>Score</html>");
                            grid[i][j].setBackground(new Color(0xCAA245)); // gold
                        }
                        case START -> {
                            // same as WS2X
                            grid[i][j].setText("★");
                            grid[i][j].setBackground(new Color(0xCAA245)); // gold
                        }
                        case WS3X -> {
                            grid[i][j].setText("<html>Triple<br>Word<br>Score</html>");
                            grid[i][j].setBackground(new Color(0xDF4132)); // red
                        }
                    }
                    grid[i][j].setBorder(new LineBorder(Color.WHITE, 1)); // white outline
                }
            }
        }
    }

    /**
     * Updates the player and number of tiles left to represent the current game
     * state
     */
    public void updateGameState(String curPlayer, int numTiles) {
        this.curPlayer.setText("<html><u>Current turn:</u><br>" + curPlayer + "</html>");
        this.tilesLeft.setText("<html><u>Number of tiles left:</u><br>" + numTiles + "</html>");
    }

    /**
     * Changes between player hands and displays placements/pick ups
     */
    public void updateHand(Player curPlayer) {
        int i = 0;

        for (Tile tile : curPlayer.getHand()) {
            handTiles[i].setText("<html>" + tile.getLetter() + "<br>" + tile.getScore());
            handTiles[i].putClientProperty("tile", tile); // Tile data to be accessed on mouse event
            handTiles[i].setVisible(true);
            i++;
        }

        while (i < 7) {
            handTiles[i++].setVisible(false); // if hand has < 7 tiles
        }
    }

    /**
     * enable/disable undo/redo based on if available
     */
    private void updateMenuItems() {
        undo.setEnabled(model.getUndoStackSize() > 0);
        redo.setEnabled(model.getRedoStackSize() > 0);
    }

    /**
     * Updates the view to represent the player's turn
     */
    public void playerTurn(Player curPlayer) {
        // re-enable board
        for (JButton[] row : grid) {
            for (JButton boardspace : row) {
                boardspace.addMouseListener(controller);
            }

        }
        // show hand
        updateHand(curPlayer);
        // re-enable player controls
        for (JButton btn : playerControls) {
            btn.setEnabled(true);
        }
    }

    /**
     * Updates the view to represent the AI's turn
     */
    public void AITurn() {
        // disable board
        for (JButton[] row : grid) {
            for (JButton boardspace : row) {
                boardspace.removeMouseListener(controller);
            }
        }
        // hide hand
        for (JButton handTile : handTiles) {
            handTile.setVisible(false);
        }
        // disable player controls
        for (JButton btn : playerControls) {
            btn.setEnabled(false);
        }

        // if (this.activeAI != AI) {
        // // avoids triggering handleTurn() on every board update
        // // only triggers once, at start of turn
        // this.activeAI = AI;
        // ((AIPlayer) model.getCurPlayer()).handleTurn();
        // }
    }

    /**
     * Updates the view to reflect the game over state
     */
    public void gameOver(ArrayList<Player> players) {
        // disable all button functionality
        for (JButton[] row : grid) {
            for (JButton boardspace : row) {
                boardspace.removeMouseListener(controller);
            }
        }
        for (JButton handTile : handTiles) {
            handTile.setVisible(false);
        }
        for (JButton btn : playerControls) {
            btn.setEnabled(false);
        }

        popUp("GAME OVER", getWinnersString(players) + "<br>" + getScoreString(players));
    }

    /**
     * Returns a string representing the current game scores
     *
     * @return String of players and respective scores
     */
    public String getScoreString(ArrayList<Player> players) {
        String str = "<html><u>Scores:</u><br>";
        for (Player p : players) {
            str += p.getName() + ": " + p.getScore() + "<br>";
        }
        return str + "</html>";
    }

    /**
     * Returns a string representing the winners
     *
     * @return String of winners
     */
    public String getWinnersString(ArrayList<Player> players) {
        // get winners
        ArrayList<Player> winners = ScrabbleModel.getWinners(players);

        String str = "<html><u>Winner";
        if (winners.size() > 1)
            str += "s";
        str += "</u><br>";

        for (Player winner : winners) {
            str += winner.getName() + "<br>";
        }

        return str + "</html>";
    }

    /**
     * Gets input from the user
     *
     * @param msg to be printed
     * @return String input written by the user
     */
    public static String getUserInput(String msg) {
        return JOptionPane.showInputDialog(null, msg);
    }

    /**
     * Gets YES/NO feedback from the user
     *
     * @param msg to be printed
     * @return int choice (YES=0, NO=1)
     */
    public static int getConfirmation(String title, String msg) {
        return JOptionPane.showConfirmDialog(null, msg, title, JOptionPane.YES_NO_OPTION);
    }

    /**
     * Popup window to display information to user
     *
     * @param title of window
     * @param msg   to be displayed
     */
    public static void popUp(String title, String msg) {
        JOptionPane.showMessageDialog(null, msg, title, JOptionPane.INFORMATION_MESSAGE);
    }

    /**
     * Displays an error to the user
     *
     * @param msg to be printed
     */
    public static void printError(String msg) {
        JOptionPane.showMessageDialog(null, msg, null, JOptionPane.WARNING_MESSAGE);
    }

    public static void main(String[] args) {
        ScrabbleView game = new ScrabbleView();
    }

}
