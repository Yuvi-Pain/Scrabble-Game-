import java.io.*;
import java.net.URISyntaxException;
import java.util.*;

/**
 * A class representing the game of Scrabble.
 *
 * @author Kyle Foisy, Peter McComb
 * @version Nov 12
 */
public class ScrabbleModel implements Serializable {
    private ArrayList<ScrabbleView> views;
    private BlankTileView blankTileView;
    private Bag bag;
    private Board board;

    private ArrayList<Player> players;
    private int curPlayerIdx;
    private Player curPlayer;

    private ScrabbleModel emptyState;
    private ScrabbleModel curState;
    private ArrayList<ScrabbleModel> undoStack;
    private ArrayList<ScrabbleModel> redoStack;

    public enum Status {
        PLAYING, GAME_OVER, AI_TURN
    }

    private int numSeqScorelessTurns = 0;
    private Status status;

    /**
     * The constructor for the game of scrabble to begin the game.
     */
    public ScrabbleModel() {
        // game setup
        bag = new Bag();
        board = new Board();
        status = Status.PLAYING;
        views = new ArrayList<>();
        // initPlayers(); // called in view, avoid repeat on state save

        // undo/redo
        undoStack = new ArrayList<>();
        redoStack = new ArrayList<>();
    }

    public ScrabbleModel(Board board) {
        // game setup
        bag = new Bag();
        this.board = board;
        status = Status.PLAYING;
        views = new ArrayList<>();
        // initPlayers(); // called on view init

        // undo/redo
        undoStack = new ArrayList<>();
        redoStack = new ArrayList<>();
    }

    /**
     * Save the current game state within the model
     */
    public void saveInitState() {
        curState = this.saveState();
        emptyState = this.saveState();
    }

    /**
     * Handle undoing a player turn
     */
    public void handleUndo() {
        if (undoStack.size() >= 1) {
            handleRemovePlacedTiles();
            redoStack.add(curState);

            // go to previous human turn
            ScrabbleModel prevPlayerTurn = undoStack.removeLast();
            while (undoStack.size() > 0
                    && prevPlayerTurn.players.get(prevPlayerTurn.curPlayerIdx) instanceof AIPlayer) {

                redoStack.add(prevPlayerTurn);
                prevPlayerTurn = undoStack.removeLast();
            }

            loadState(prevPlayerTurn); // load prev turn
            updateViews();

            if (this.curPlayer instanceof AIPlayer)
                ((AIPlayer) this.curPlayer).handleTurn(); // defensive programming
        }
    }

    /**
     * Handle redoing a player turn
     */
    public void handleRedo() {
        if (redoStack.size() >= 1) {
            handleRemovePlacedTiles();
            undoStack.add(curState);

            // go to previous human turn
            ScrabbleModel redoPlayerTurn = redoStack.removeLast();
            while (redoStack.size() > 0
                    && redoPlayerTurn.players.get(redoPlayerTurn.curPlayerIdx) instanceof AIPlayer) {

                undoStack.add(redoPlayerTurn);
                redoPlayerTurn = redoStack.removeLast();
            }

            loadState(redoPlayerTurn); // load undone turn
            updateViews();

            if (this.curPlayer instanceof AIPlayer)
                ((AIPlayer) this.curPlayer).handleTurn(); // defensive programming
        }
    }

    /**
     * Get size of undo stack
     * 
     * @return size of undo stack
     */
    public int getUndoStackSize() {
        return undoStack.size();
    }

    /**
     * Get size of redo stack
     * 
     * @return size of redo stack
     */
    public int getRedoStackSize() {
        return redoStack.size();
    }

    /**
     * Written by Daniel Afanassiev
     * Handle saving the current game state
     */
    public void handleSave() {
        String fileSaveName = ScrabbleView.getUserInput("Enter save file name");
        try {
            if (fileSaveName == null) {
                return;
            }
            String path = new File(ScrabbleModel.class.getProtectionDomain().getCodeSource().getLocation().toURI())
                    .getParentFile().getPath();
            File saveFile = new File(path + "\\" + fileSaveName + ".ser");
            FileOutputStream fileOut = new FileOutputStream(saveFile);
            ObjectOutputStream out = new ObjectOutputStream(fileOut);
            out.writeObject(curState);
            System.out.println("Saved game at: " + saveFile.getAbsolutePath());
        } catch (IOException | URISyntaxException e) {
            e.printStackTrace();
        }

    }

    /**
     * Written by Daniel Afanassiev
     * Handle loading a saved game state
     */
    public void handleLoad() {
        String fileSaveName = ScrabbleView.getUserInput("Enter save file name. (\"file name\".ser)");
        try {
            if (fileSaveName == null) {
                return;
            }
            String path = new File(ScrabbleModel.class.getProtectionDomain().getCodeSource().getLocation().toURI())
                    .getParentFile().getPath();
            File loadFile = new File(path + "\\" + fileSaveName + ".ser");
            FileInputStream fileIn = new FileInputStream(loadFile);
            ObjectInputStream in = new ObjectInputStream(fileIn);
            curState = (ScrabbleModel) in.readObject();

            // Clear undo/redo stacks
            undoStack.clear();
            redoStack.clear();

            loadState(curState);
            System.out.println("Loaded game at: " + loadFile.getAbsolutePath());
        } catch (Exception e) {
            e.printStackTrace();
        }
        updateViews();
    }

    /**
     * Handle loading a custom baord
     */
    public void handleLoadBoard(Board customBoard) {
        handleRemovePlacedTiles();
        loadState(emptyState); // reset bag, players, etc
        this.board = customBoard;

        // re-randomize first player
        Random rand = new Random();
        curPlayerIdx = rand.nextInt(players.size());
        curPlayer = players.get(curPlayerIdx);

        this.undoStack.clear();
        this.redoStack.clear();

        saveInitState();
        updateViews();
    }

    /**
     * Handle an attempted tile placement
     *
     * @param draggedTile       representing the tile dragged from the player's hand
     * @param hoveredBoardspace representing the boardspace of the placement
     */
    public void handleDragDrop(Tile draggedTile, BoardSpace hoveredBoardspace) {
        if (draggedTile.getLetter() == ' ') { // Doing this instead of isBlank to handle issue where blank tile
                                              // selection pops up while returning tile to hand
            blankTileView = new BlankTileView(this, hoveredBoardspace, (BlankTile) draggedTile);
        }
        if (curPlayer.hasTile(draggedTile)) {
            // dragged tile may already be placed on the board
            curPlayer.removeTile(draggedTile);
        }
        board.placeTile(draggedTile, hoveredBoardspace);
        updateViews();
    }

    /**
     * Handle picking up a tile by removing it from player's hand
     * Prevents tile duplication bug
     *
     * @param draggedTile representing the tile dragged from the player's hand
     */
    public void handlePickUpTile(Tile draggedTile) {
        if (curPlayer.hasTile(draggedTile))
            curPlayer.removeTile(draggedTile);
        // updateViews(); // could choose to have it vanish while being held
    }

    /**
     * Handle returning a placed tile to the user's hand
     *
     * @param clickedBoardspace representing where the tile is located
     */
    public void handleReturnTileToHand(BoardSpace clickedBoardspace) {
        Tile tile = board.removeTile(clickedBoardspace.getRow(), clickedBoardspace.getCol());

        if (tile.isBlank()) {
            ((BlankTile) tile).clearLetter();
        }
        if (tile == null) { // Defensive programming incase we get an input grabbing from black tile
            ScrabbleView.printError("Cannot grab tile from here!");
        } else {
            curPlayer.addTile(tile);
            updateViews();
        }
    }

    /**
     * Handle returning a picked up tile to the user's hand
     *
     * @param tile representing the picked up tile
     */
    public void handleReturnTileToHand(Tile tile) {
        if (tile == null) { // Defensive programming incase we get an input grabbing from black tile
            ScrabbleView.printError("Cannot grab tile from here!");
        } else {
            if (tile.isBlank()) {
                tile = (BlankTile) tile;
                ((BlankTile) tile).clearLetter();
            }
            curPlayer.addTile(tile);
            updateViews();
        }
    }

    /**
     * Handle an attempted word placement
     *
     * @return true if word was successfully placed
     */
    public Boolean handleConfirmWord() {
        board.clearCurrentWords();

        String orientation = board.areInline(); // Get the orientation of our word

        if (orientation.equals("invalid")) {
            // tiles not aligned
            return false;

        } else if (orientation.equals("1")) {
            // single tile being placed
            board.findHorizontalWords(); // Find all vertically formed words
            board.findVertWords(); // Find all horizontally confirmed words

        } else if (orientation.equals("col")) {
            // tiles are aligned vertically

            // Find the word formed by tiles and stop if not all tiles in word
            // Also stop if word formed does not contain at least 1 previously placed letter
            if (!board.findVertWord()) {
                return false;
            }

            board.findHorizontalWords(); // Find any horizontal words formed

        } else if (orientation.equals("row")) {
            // tiles are aligned horizontally

            // Find the word formed by tiles and stop if not all tiles in word
            // Also stop if word formed does not contain at least 1 previously placed letter
            if (!board.findHorizontalWord()) {
                return false;
            }

            board.findVertWords(); // Find any vertical words formed
        }

        // Check if any words are formed and if they are all valid
        if (!board.validWords()) {
            return false;
        }

        // At this point word placement is valid
        int score = board.calcScore(); // Get sum of scores for words formed
        curPlayer.increaseScore(score); // Increase score of player
        board.lockCurPlacement(); // Lock all placements
        board.clearCurrentPlacements();

        if (score == 0) { // If somehow player scored 0, increment number of scoreless turns
            numSeqScorelessTurns++;
        }

        draw(); // Replace player tiles
        numSeqScorelessTurns = 0;

        return true;
    }

    /**
     * Handles returning all placed tiles to current player's hand
     */
    public void handleRemovePlacedTiles() {
        for (Tile tile : board.removeAll()) {
            if (tile.isBlank()) {
                tile = (BlankTile) tile;
                ((BlankTile) tile).clearLetter();
            }

            if (curPlayer == null)
                curPlayer = players.get(curPlayerIdx); // undo bug

            curPlayer.addTile(tile);
        }
        updateViews();
    }

    /**
     * Handles the functionality for a player to exchange their tiles for new tiles
     * from the bag.
     *
     * @return True if the exchange was successful, false otherwise.
     */
    public Boolean handleExchange(ArrayList<Tile> tiles) {
        if (getNumTilesLeft() < 7) {
            return false;
        }

        for (Tile tile : tiles) {
            curPlayer.removeTile(tile); // remove from hand
        }

        draw();

        // add exchanged tile(s) back to bag afterwards to avoid redrawing
        for (Tile tile : tiles) {
            bag.putTileInBag(tile);
        }
        numSeqScorelessTurns++;

        if (!(curPlayer instanceof AIPlayer)) {
            handleEndTurn(); // humans ends turn here
        }

        return true;
    }

    /**
     * Confirms if the user wants to skip their turn
     */
    public void handlePassTurn() {
        handleRemovePlacedTiles();
        numSeqScorelessTurns++;
        handleEndTurn();
    }

    /**
     * Ends the current player's turn
     */
    public void handleEndTurn() {
        checkGameEnd();
        switchCurPlayer();
        undoStack.add(curState); // save current board
        curState = this.saveState();
        redoStack.clear(); // can no longer redo (EXPECTED BEHAVIOUR)
        updateViews();

        if (this.status == Status.AI_TURN)
            ((AIPlayer) curPlayer).handleTurn();
    }

    /**
     * creates a copy of the current game state.
     * 
     * @return copy of current model.
     */
    private ScrabbleModel saveState() {
        ScrabbleModel state = new ScrabbleModel();

        state.bag = this.bag.createCopy();
        state.board = this.board.createCopy();
        state.players = new ArrayList<>();
        for (Player player : this.players) {
            if (player instanceof AIPlayer) {
                state.players.add(((AIPlayer) player).createCopy(this));
            } else {
                state.players.add(player.createCopy());
            }
        }
        state.curPlayerIdx = this.curPlayerIdx;
        state.status = this.status;
        state.numSeqScorelessTurns = this.numSeqScorelessTurns;

        System.out.println("STATE SAVED");
        return state;
    }

    /**
     * loads a game state.
     */
    private void loadState(ScrabbleModel state) {
        this.bag = state.bag;
        this.board = state.board;
        this.players = state.players;
        this.curPlayerIdx = state.curPlayerIdx;
        this.curPlayer = this.players.get(state.curPlayerIdx);
        this.status = state.status;
        this.numSeqScorelessTurns = state.numSeqScorelessTurns;

        System.out.println("STATE LOADED");
        curState = this.saveState();
    }

    /**
     * Adds listener ScrabbleViews to be updated on game state changes
     *
     * @param view of game state
     */
    public void addView(ScrabbleView view) {
        this.views.add(view);
    }

    /**
     * Removes view from list of views to be updated.
     */
    public void removeView(ScrabbleView view) {
        this.views.remove(view);
    }

    /**
     * Gets user input for number of players and player names
     */
    public void initPlayers() {
        // get number of players
        int numPlayers = 0;
        while (numPlayers < 2) {
            String numPlayersInput = ScrabbleView.getUserInput("Enter the number of players (2 to 4):");
            try {
                numPlayers = Integer.parseInt(numPlayersInput);
                if (numPlayers < 2 || numPlayers > 4) {
                    ScrabbleView.printError("Please enter a number between 2 and 4.");
                }
            } catch (NumberFormatException e) {
                ScrabbleView.printError("Invalid input. Please enter a number.");
            }
        }
        players = new ArrayList<>(numPlayers);

        // get player names
        ArrayList<Player> playerNames = new ArrayList<Player>();
        for (int i = 1; i <= numPlayers; i++) {
            String playerName = ScrabbleView.getUserInput("Enter name for Player " + i + ":");
            if (playerName == null || playerName.isEmpty()) {
                playerName = "Player " + i; // default name: Player <i>
            }

            if (ScrabbleView.getConfirmation("AI Player?", "Is " + playerName + " an AI?") == 1) {
                // human player
                playerNames.add(new Player(playerName));
            } else {
                // AI player
                playerNames.add(new AIPlayer(playerName, this));
            }
        }

        // draw tiles
        setPlayers(playerNames);
    }

    /**
     * Retrieves information for each player from the user. Adds each player to the
     * game and randomized the starting player.
     */
    public void setPlayers(ArrayList<Player> players) {
        this.players = players;

        // draw initial hand
        for (Player player : this.players) {
            for (int i = 0; i < 7; i++) {
                player.addTile(bag.grabTile());
            }
        }

        // randomize first player
        Random rand = new Random();
        curPlayerIdx = rand.nextInt(players.size());
        curPlayer = players.get(curPlayerIdx);
    }

    /**
     * Returns the list of players
     *
     * @return an ArrayList of Players
     */
    public ArrayList<Player> getPlayers() {
        return players;
    }

    /**
     * Switches to the next player in the list of players.
     */
    public void switchCurPlayer() {
        curPlayerIdx += 1;

        if (curPlayerIdx >= players.size()) {
            curPlayerIdx = 0; // back to player 1
        }

        curPlayer = players.get(curPlayerIdx);

        if (status != Status.GAME_OVER) {
            if (curPlayer instanceof AIPlayer) {
                status = Status.AI_TURN; // AI player's turn
            } else {
                status = Status.PLAYING;
            }
        }
    }

    /**
     * Retrieves the current player from the list of players.
     */
    public Player getCurPlayer() {
        return curPlayer;
    }

    /**
     * Returns the number of tiles left in the bag
     *
     * @return int representing the number of tiles
     */
    public int getNumTilesLeft() {
        return bag.getNumTilesLeft();
    }

    /**
     * Makes the current player draw until they have 7 tiles or the bag is empty.
     */
    public void draw() {
        while (curPlayer.tileCount() < 7 && getNumTilesLeft() > 0) {
            curPlayer.addTile(bag.grabTile());
        }
    }

    /**
     * Determines if the game should end because:
     * - 6 turns with no points scored have passed
     * - the bag is empty and a player has no tiles left.
     * Updates the status accordingly.
     */
    public void checkGameEnd() {
        for (Player player : players) {
            if ((player.tileCount() == 0) && getNumTilesLeft() == 0) {
                status = Status.GAME_OVER;
                gameOver();
            }
        }
        if (numSeqScorelessTurns > 5) {
            // 6 consecutive turns with no points scored
            if (ScrabbleView.getConfirmation("End Game?", "6 turns passed, end the game?") == 0) {
                status = Status.GAME_OVER;
                gameOver();
            }
        }
    }

    /**
     * Handles the end of the game by calculating final scores and displaying
     * results.
     */
    public void gameOver() {
        calcFinalScores();
    }

    /**
     * Returns the current Bag in the game. Solely used for testing.
     *
     * @return The current Bag in the game
     */
    public Bag getBag() {
        return bag;
    }

    /**
     * Determines the final scores of each player. If a player plays out, add the
     * score of all remaining tiles in
     * the other player's hands to their score. For all other players, subtract
     * remaining score for each tile in their.
     */
    private void calcFinalScores() {
        int totalTileScore = 0;
        int playerScore;

        for (Player player : players) {
            ArrayList<Tile> hand = player.getHand();
            playerScore = 0;
            for (Tile tile : hand) {
                playerScore += tile.getScore();
            }
            player.decreaseScore(playerScore);
            totalTileScore += playerScore;
        }

        for (Player player : players) {
            if (player.tileCount() == 0) {
                player.increaseScore(totalTileScore);
            }
        }
    }

    /**
     * Returns the current board state
     *
     * @return The scrabble board for this model
     */
    public Board getBoard() {
        return board;
    }

    /**
     * Determines who won this Scrabble game.
     *
     * @params ArrayList of player
     * @return an ArrayList of players who won the game.
     */
    public static ArrayList<Player> getWinners(ArrayList<Player> players) {
        ArrayList<Player> winners = new ArrayList<>();

        int highscore = -100;
        for (Player player : players) {
            if (player.getScore() > highscore) {
                highscore = player.getScore();
            }
        }

        // winners are players that match highest score
        for (Player player : players) {
            if (player.getScore() == highscore) {
                winners.add(player);
            }
        }

        return winners;
    }

    /**
     * Update view based on new game state
     */
    public void updateViews() {
        for (ScrabbleView view : views) {
            view.handleStatusUpdate(
                    new ScrabbleEvent(this, players, board, this.players.get(curPlayerIdx), getNumTilesLeft(), status));
        }
    }

}
