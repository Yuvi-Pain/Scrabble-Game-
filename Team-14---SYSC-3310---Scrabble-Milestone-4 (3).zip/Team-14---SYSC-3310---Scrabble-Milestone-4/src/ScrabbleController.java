import javax.swing.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.MouseEvent;
import java.awt.event.MouseListener;
import java.io.File;
import java.net.URL;
import java.nio.file.Paths;

public class ScrabbleController implements ActionListener, MouseListener {
    private ScrabbleModel model;
    private ScrabbleView view;
    private ExchangeView exchangeView;
    private Tile draggedTile;
    private BoardSpace hoveredBoardspace;

    public ScrabbleController(ScrabbleModel model, ScrabbleView view) {
        this.model = model;
        this.view = view;
    }

    @Override
    public void actionPerformed(ActionEvent e) {
        String command = e.getActionCommand();

        switch (command) {
            case "undo" -> {
                model.handleUndo();
            }
            case "redo" -> {
                model.handleRedo();
            }
            case "save" -> {
                model.handleSave();
            }
            case "load" -> {
                model.handleLoad();
            }
            case "loadBoard" -> {
                String filepath = ScrabbleView
                        .getUserInput("Enter save file name of custom board. (\"file name\".txt)");

                if (filepath == null)
                    return;

                filepath += ".txt";

                try {
                    String srcPath = new File(
                            ScrabbleController.class.getProtectionDomain().getCodeSource().getLocation().toURI())
                            .getParentFile().getPath();

                    String fullPath = srcPath + "\\" + filepath;
                    System.out.println(fullPath);

                    String[][] newBoardStr = BoardLoader.loadBoard(fullPath);
                    Board board = new Board(newBoardStr);

                    model.handleLoadBoard(board);
                } catch (Exception ex) {
                    ScrabbleView.printError("Failed to load board");
                }
            }
            case "confirmWord" -> {
                if (model.handleConfirmWord()) {
                    // on success
                    model.handleEndTurn();
                } else {
                    // on fail
                    ScrabbleView.printError("Invalid placement or word!");
                }
            }
            case "removePlaced" -> {
                model.handleRemovePlacedTiles();
            }
            case "exchangeTiles" -> {
                if (model.getNumTilesLeft() < 7) {
                    ScrabbleView.printError("Cannot place while less than 7 tiles in bag!");
                } else {
                    exchangeView = new ExchangeView(model.getCurPlayer().getHand(), model); // must wait for this
                }
            }
            case "passTurn" -> {
                if (ScrabbleView.getConfirmation("Are you sure?", "Pass your turn?") == 0) {
                    // Prompt user to confirm they want to pass their turn
                    model.handlePassTurn();
                }
            }
        }
    }

    @Override
    public void mouseClicked(MouseEvent e) {
        JButton btn = (JButton) e.getSource();

        if (((String) btn.getClientProperty("type")).equals("boardspace")) {
            int row = (int) btn.getClientProperty("row");
            int col = (int) btn.getClientProperty("col");
            BoardSpace clickedBoardspace = model.getBoard().getBoardSpace(row, col);

            if (clickedBoardspace.hasTile() && !clickedBoardspace.getTile().isPlaced()) {
                // return placed tile to player's hand
                model.handleReturnTileToHand(clickedBoardspace);
            }
        }
    }

    @Override
    public void mousePressed(MouseEvent e) {
        JButton btn = (JButton) e.getSource();

        switch ((String) btn.getClientProperty("type")) {
            case "tile":
                // pick up tile from hand
                draggedTile = (Tile) btn.getClientProperty("tile");

                model.handlePickUpTile(draggedTile);
                break;

            case "boardspace":
                // pick up previously placed tile from board
                int row = (int) btn.getClientProperty("row");
                int col = (int) btn.getClientProperty("col");
                BoardSpace boardspace = model.getBoard().getBoardSpace(row, col);

                if (boardspace.hasTile() && !boardspace.getTile().isPlaced()) {
                    draggedTile = model.getBoard().removeTile(row, col);
                }
                break;
        }
    }

    @Override
    public void mouseReleased(MouseEvent e) {
        if (draggedTile != null) {
            // drop the tile
            if (hoveredBoardspace != null && !hoveredBoardspace.hasTile()) {
                model.handleDragDrop(draggedTile, hoveredBoardspace);
            } else {
                model.handleReturnTileToHand(draggedTile);
            }
            draggedTile = null;
        }
    }

    @Override
    public void mouseEntered(MouseEvent e) {
        JButton btn = (JButton) e.getSource();

        if (((String) btn.getClientProperty("type")).equals("boardspace")) {
            // hover over a boardspace
            int row = (int) btn.getClientProperty("row");
            int col = (int) btn.getClientProperty("col");
            hoveredBoardspace = model.getBoard().getBoardSpace(row, col);
        }
    }

    @Override
    public void mouseExited(MouseEvent e) {
        // no longer hovering over a boardspace
        hoveredBoardspace = null;
    }
}
