import java.util.ArrayList;
import java.util.EventObject;

public class ScrabbleEvent extends EventObject {
    private ArrayList<Player> players;
    private Board board;
    private Player curPlayer;
    private int numTiles;
    private ScrabbleModel.Status status;

    public ScrabbleEvent(ScrabbleModel model, ArrayList<Player> players, Board board, Player curPlayer, int numTiles,
            ScrabbleModel.Status status) {
        super(model);
        this.board = board;
        this.players = players;
        this.curPlayer = curPlayer;
        this.numTiles = numTiles;
        this.status = status;
    }

    /**
     * Returns the current board state
     *
     * @return The board for this game
     */
    public Board getBoard() {
        return board;
    }

    /**
     * Returns a list of all players
     *
     * @return The list of players for this game
     */
    public ArrayList<Player> getPlayers() {
        return players;
    }

    /**
     * Returns the current player
     *
     * @return The current player for this game
     */
    public Player getCurPlayer() {
        return curPlayer;
    }

    /**
     * Returns the number of tiles remaining
     *
     * @return the number of tiles remaining
     */
    public int getNumTiles() {
        return numTiles;
    }

    /**
     * Returns the game status
     */
    public ScrabbleModel.Status getStatus() {
        return this.status;
    }
}
