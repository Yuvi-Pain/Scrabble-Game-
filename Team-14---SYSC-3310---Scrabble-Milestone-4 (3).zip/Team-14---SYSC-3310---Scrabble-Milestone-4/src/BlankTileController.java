import javax.swing.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

/**
 * Handles user inputs for BlankTileView
 *
 * @author Daniel Afanassiev
 */

public class BlankTileController implements ActionListener {
    private BlankTileView view;
    private ScrabbleModel model;
    private BoardSpace hoveredSpace;
    private int selectedLetter;
    private BlankTile tile;
    private String[] alphabet = {"A","B","C","D","E","F","G","H","I","J","K","L","M","N","O","P","Q","R","S","T","U","V","W","X","Y","Z"};

    /**
     * The constructor for this class.
     * Written by Daniel Afanassiev.
     *
     * @param model The scrabble model.
     * @param view The corresponding Blank tile view for this controller.
     * @param hoveredSpace The space which will have the blank tile added to.
     */
    BlankTileController(ScrabbleModel model, BlankTileView view, BoardSpace hoveredSpace, BlankTile tile){
        this.model = model;
        this.view = view;
        this.hoveredSpace = hoveredSpace;
        this.tile = tile;

        selectedLetter = -1;
    }

    @Override
    public void actionPerformed(ActionEvent e){
        if(e.getActionCommand().equals("confirm")){ //Player confirms letter selection
            handleConfirm();
        }
        else if (e.getActionCommand().equals("cancel")){ //Player decides not to use blank tile anymore
            model.handleReturnTileToHand(hoveredSpace);
            view.dispose();
        }
        else { //When a player selects a letter from the alphabet to play, game illuminates that letter and assigns selectedLetter to their chosen letter
            int i = Integer.parseInt(e.getActionCommand());
            selectedLetter = i;
            view.updateButtons(i);
        }
    }

    /**
     * Invoked when the player presses Confirm.
     * Passes letter which the player selected to use in their word.
     * Notifies player if they did not select a letter.
     *
     * Written by Daniel Afanassiev.
     */
    private void handleConfirm(){
        if(selectedLetter == -1){
            JOptionPane.showMessageDialog(new JFrame(), "No letter selected!", null, JOptionPane.WARNING_MESSAGE);
            return;
        }
        else{
            view.dispose();
            tile.setLetter(alphabet[selectedLetter].charAt(0));
            model.updateViews();
        }
    }
}
