import java.io.Serializable;

/**
 * A class representing a BoardSpace on a board in Scrabble.
 *
 * @author Kyle Foisy, Peter McComb
 * @version Nov 13
 */
public class BoardSpace implements Serializable {
    private Tile tile;
    private Modifier modifier;

    public enum Modifier {
        NONE, LS2X, LS3X, WS2X, WS3X, START
    };

    private int row;
    private int col;

    /**
     * A constructor for a single BoardSpace on the Scrabble board. Each space has a
     * designation for if it is blank,
     * the starting space, a 2x-LS, 3x-LS, 2x-WS or 3x-WS.
     *
     * @param modifier The designation of the space.
     */
    public BoardSpace(Modifier modifier) {
        tile = null;
        this.modifier = modifier;
    }

    /**
     * The designation assigned to the BoardSpace (Blank is " - ")
     *
     * @return The modifier of the boardspace
     */
    public Modifier getModifier() {
        return modifier;
    }

    /**
     * Return the tile placed on the boardspace if one exists.
     *
     * @return The tile placed on the BoardSpace. Null if there is no tile.
     */
    public Tile getTile() {
        return tile;
    }

    /**
     * Returns a boolean indicating if there is a tile on this boardspace.
     *
     * @return True if there is a tile on the BoardSpace.
     */
    public boolean hasTile() {
        return tile != null;
    }

    /**
     * Places a tile on this boardspace.
     * 
     * @return True if tile was successfully placed
     */
    public Boolean setTile(Tile tile) {
        if (hasTile())
            return false; // tile already here

        this.tile = tile;
        return true; // tile placed successfully
    }

    /**
     * Records the row this boardspace is in.
     *
     * @param row The row of the Boardspace
     */
    public void setRow(int row) {
        this.row = row;
    }

    /**
     * Returns the row this boardspace is in
     *
     * @return The row of the boardspace
     */
    public int getRow() {
        return row;
    }

    /**
     * Records the column this boardspace is in.
     *
     * @param col The column of the Boardspace
     */
    public void setCol(int col) {
        this.col = col;
    }

    /**
     * Returns the column this bpardspace is in
     *
     * @return The column the Boardspace is in
     */
    public int getCol() {
        return col;
    }

    /**
     * Removes a tile from this boardspace.
     * 
     * @return tile that was removed
     */
    public Tile removeTile() {
        Tile removedTile = this.tile;
        tile = null;
        if (removedTile != null) {
            return removedTile;
        } else {
            throw new RuntimeException("Trying to remove null tile!");
            // return null;
        }

    }

}
