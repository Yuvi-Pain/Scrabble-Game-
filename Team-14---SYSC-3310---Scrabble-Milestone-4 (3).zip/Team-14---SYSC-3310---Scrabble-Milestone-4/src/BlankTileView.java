import javax.swing.*;
import java.awt.*;

/**
 * Represents a popup window used by the player to select which letter they want to use for their blank tile
 *
 * @author Daniel Afanassiev
 */
public class BlankTileView extends JFrame {
    private ScrabbleModel model;
    private BlankTileController controller;
    private JButton[] buttons;
    private String[] alphabet = {"A","B","C","D","E","F","G","H","I","J","K","L","M","N","O","P","Q","R","S","T","U","V","W","X","Y","Z"};

    /**
     * The constructor for this class
     *
     * @param model The scrabble model
     * @param hoveredSpace The space which the blank tile will be placed on
     */
    public BlankTileView(ScrabbleModel model, BoardSpace hoveredSpace, BlankTile tile) {
        super("Blank Tile Selection");
        controller = new BlankTileController(model, this, hoveredSpace, tile);

        this.setLayout(new BorderLayout());
        JLabel text = new JLabel("Select what letter you would like the blank tile to represent");
        JPanel alphabetPanel = new JPanel(new GridLayout(5,5));
        JPanel buttonPanel=  new JPanel(new GridLayout(1,2));

        buttons = new JButton[26];

        //Panel for the alphabet
        for (int i = 0; i < alphabet.length; i++) {
            JButton button = new JButton();
            button.setText("<html>" + alphabet[i] + "<br>" + 0);
            button.setBackground(new Color(0xE9D09E)); // wood brown
            button.setActionCommand(Integer.toString(i));
            button.addActionListener(controller);
            alphabetPanel.add(button);
            buttons[i] = button;
            button.setVisible(true);
        }

        //Buttons to confirm their selection
        JButton confirmButton = new JButton("Confirm");
        confirmButton.setActionCommand("confirm");
        confirmButton.addActionListener(controller);
        buttonPanel.add(confirmButton);
        confirmButton.setVisible(true);

        //Buttons to cancel their selection
        JButton cancelButton = new JButton("Cancel");
        cancelButton.setActionCommand("cancel");
        cancelButton.addActionListener(controller);
        buttonPanel.add(cancelButton);
        cancelButton.setVisible(true);

        this.add(text, BorderLayout.NORTH);
        this.add(alphabetPanel, BorderLayout.CENTER);
        this.add(buttonPanel, BorderLayout.SOUTH);
        this.setSize(500,500);
        this.setResizable(false);
        this.setLocation(500,300);
        this.setVisible(true);
        this.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
    }

    /**
     * Changes the colour of the selected letter to be used on the board.
     *
     * @param selected the index of the selected letter
     */
    public void updateButtons(int selected){
        for (int i = 0; i < 26; i++) {
            if (i == selected) {
                buttons[i].setBackground(new Color(0x92B5D4)); //Light Blue
            }
            else {
                buttons[i].setBackground(new Color(0xE9D09E)); // wood brown
            }
        }
    }
}
