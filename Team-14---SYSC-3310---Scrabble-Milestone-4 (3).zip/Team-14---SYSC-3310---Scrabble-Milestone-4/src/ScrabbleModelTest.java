import org.junit.Assert;
import org.junit.Test;

import static org.junit.Assert.*;

public class ScrabbleModelTest {
    // PLACEMENTS
    @Test
    public void testValidFirstWordPlacement() {
        ScrabbleModel game = new ScrabbleModel();
        Player player = new Player("TestPlayer");
        game.setPlayers(new java.util.ArrayList<>(java.util.Arrays.asList(player)));

        Tile tileW = new Tile('W');
        Tile tileO = new Tile('O');
        Tile tileR = new Tile('R');
        Tile tileD = new Tile('D');

        game.handleDragDrop(tileW, game.getBoard().getBoardSpace(7, 7));
        game.handleDragDrop(tileO, game.getBoard().getBoardSpace(7, 8));
        game.handleDragDrop(tileR, game.getBoard().getBoardSpace(7, 9));
        game.handleDragDrop(tileD, game.getBoard().getBoardSpace(7, 10));

        assertTrue(game.handleConfirmWord()); // word covers center boardspace
    }

    @Test
    public void testInvalidFirstWordPlacement() {
        ScrabbleModel game = new ScrabbleModel();
        Player player = new Player("TestPlayer");
        game.setPlayers(new java.util.ArrayList<>(java.util.Arrays.asList(player)));

        Tile tileW = new Tile('W');
        Tile tileO = new Tile('O');
        Tile tileR = new Tile('R');
        Tile tileD = new Tile('D');

        game.handleDragDrop(tileW, game.getBoard().getBoardSpace(7, 8));
        game.handleDragDrop(tileO, game.getBoard().getBoardSpace(7, 9));
        game.handleDragDrop(tileR, game.getBoard().getBoardSpace(7, 10));
        game.handleDragDrop(tileD, game.getBoard().getBoardSpace(7, 11));

        Assert.assertFalse(game.handleConfirmWord()); // no tile on center boardspace
    }

    @Test
    public void testLeadingWordPlacement() {
        // HORIZONTAL
        ScrabbleModel game = new ScrabbleModel();
        Player player = new Player("TestPlayer");
        game.setPlayers(new java.util.ArrayList<>(java.util.Arrays.asList(player)));

        Tile tileW = new Tile('W');
        Tile tileO = new Tile('O');
        Tile tileR = new Tile('R');
        Tile tileD = new Tile('D');
        game.handleDragDrop(tileW, game.getBoard().getBoardSpace(7, 7));
        game.handleDragDrop(tileO, game.getBoard().getBoardSpace(7, 8));
        game.handleDragDrop(tileR, game.getBoard().getBoardSpace(7, 9));
        game.handleDragDrop(tileD, game.getBoard().getBoardSpace(7, 10));

        assertTrue(game.handleConfirmWord()); // word covers center boardspace

        Tile tileS = new Tile('S');
        game.handleDragDrop(tileS, game.getBoard().getBoardSpace(7, 6));

        assertTrue(game.handleConfirmWord()); // single letter leads word (WORD -> SWORD)

        Tile tileP = new Tile('P');
        Tile tileA = new Tile('A');
        Tile tileS2 = new Tile('S');
        game.handleDragDrop(tileP, game.getBoard().getBoardSpace(7, 3));
        game.handleDragDrop(tileA, game.getBoard().getBoardSpace(7, 4));
        game.handleDragDrop(tileS2, game.getBoard().getBoardSpace(7, 5));

        assertTrue(game.handleConfirmWord()); // multiple letters lead word (SWORD -> PASSWORD)

        // VERTICAL
        game = new ScrabbleModel();
        player = new Player("TestPlayer");
        game.setPlayers(new java.util.ArrayList<>(java.util.Arrays.asList(player)));

        game.handleDragDrop(tileW, game.getBoard().getBoardSpace(7, 7));
        game.handleDragDrop(tileO, game.getBoard().getBoardSpace(8, 7));
        game.handleDragDrop(tileR, game.getBoard().getBoardSpace(9, 7));
        game.handleDragDrop(tileD, game.getBoard().getBoardSpace(10, 7));

        assertTrue(game.handleConfirmWord()); // word covers center boardspace

        game.handleDragDrop(tileS, game.getBoard().getBoardSpace(6, 7));

        assertTrue(game.handleConfirmWord()); // single letter leads word (WORD -> SWORD)

        game.handleDragDrop(tileP, game.getBoard().getBoardSpace(3, 7));
        game.handleDragDrop(tileA, game.getBoard().getBoardSpace(4, 7));
        game.handleDragDrop(tileS2, game.getBoard().getBoardSpace(5, 7));

        assertTrue(game.handleConfirmWord()); // multiple letters lead word (SWORD -> PASSWORD)
    }

    @Test
    public void testTailingWordPlacement() {
        // HORIZONTAL
        ScrabbleModel game = new ScrabbleModel();
        Player player = new Player("TestPlayer");
        game.setPlayers(new java.util.ArrayList<>(java.util.Arrays.asList(player)));

        Tile tileL = new Tile('L');
        Tile tileA = new Tile('A');
        game.handleDragDrop(tileL, game.getBoard().getBoardSpace(7, 7));
        game.handleDragDrop(tileA, game.getBoard().getBoardSpace(7, 8));

        assertTrue(game.handleConfirmWord()); // word covers center boardspace

        Tile tileB = new Tile('B');
        game.handleDragDrop(tileB, game.getBoard().getBoardSpace(7, 9));

        assertTrue(game.handleConfirmWord()); // single letter tails word (LA -> LAB)

        Tile tileE = new Tile('E');
        Tile tileL2 = new Tile('L');
        game.handleDragDrop(tileE, game.getBoard().getBoardSpace(7, 10));
        game.handleDragDrop(tileL2, game.getBoard().getBoardSpace(7, 11));

        assertTrue(game.handleConfirmWord()); // multiple letters tail word (LAB -> LABEL)

        // VERTICAL
        game = new ScrabbleModel();
        player = new Player("TestPlayer");
        game.setPlayers(new java.util.ArrayList<>(java.util.Arrays.asList(player)));

        game.handleDragDrop(tileL, game.getBoard().getBoardSpace(7, 7));
        game.handleDragDrop(tileA, game.getBoard().getBoardSpace(8, 7));

        assertTrue(game.handleConfirmWord()); // word covers center boardspace

        game.handleDragDrop(tileB, game.getBoard().getBoardSpace(9, 7));

        assertTrue(game.handleConfirmWord()); // single letter tails word (LA -> LAB)

        // Add multiple letters to form "LABEL" vertically, continuing from (10, 7)
        game.handleDragDrop(tileE, game.getBoard().getBoardSpace(10, 7));
        game.handleDragDrop(tileL2, game.getBoard().getBoardSpace(11, 7));

        assertTrue(game.handleConfirmWord()); // multiple letters tail word (LAB -> LABEL)
    }

    @Test
    public void testGapWordPlacement() {
        ScrabbleModel game = new ScrabbleModel();
        Player player = new Player("TestPlayer");
        game.setPlayers(new java.util.ArrayList<>(java.util.Arrays.asList(player)));

        Tile tileW = new Tile('W');
        Tile tileO = new Tile('O');
        Tile tileR = new Tile('R');
        Tile tileD = new Tile('D');
        game.handleDragDrop(tileW, game.getBoard().getBoardSpace(7, 7));
        game.handleDragDrop(tileO, game.getBoard().getBoardSpace(7, 8));
        game.handleDragDrop(tileR, game.getBoard().getBoardSpace(7, 9));
        game.handleDragDrop(tileD, game.getBoard().getBoardSpace(7, 10));
        // W O R D
        assertTrue(game.handleConfirmWord()); // word covers center boardspace played horizontally

        Tile tileP = new Tile('P');
        Tile tileT = new Tile('T');
        game.handleDragDrop(tileP, game.getBoard().getBoardSpace(6, 8));
        game.handleDragDrop(tileT, game.getBoard().getBoardSpace(8, 8));
        // SINGLE GAP VERTICAL:
        //   P
        // W O R D
        //   T
        assertTrue("SINGLE GAP VERTICAL - failed", game.handleConfirmWord());

        Tile tileS = new Tile('S');
        Tile tileS2 = new Tile('S');
        game.handleDragDrop(tileS, game.getBoard().getBoardSpace(5, 8));
        game.handleDragDrop(tileS2, game.getBoard().getBoardSpace(9, 8));
        // MULTIPLE GAP VERTICAL:
        //   S
        //   P
        // W O R D
        //   T
        //   S
        assertTrue("MULTIPLE GAP VERTICAL - failed", game.handleConfirmWord());

        Tile tileT2 = new Tile('T');
        Tile tileH = new Tile('H');
        Tile tileE = new Tile('E');
        Tile tileI = new Tile('I');
        Tile tileS3 = new Tile('S');
        game.handleDragDrop(tileT2, game.getBoard().getBoardSpace(9, 5));
        game.handleDragDrop(tileH, game.getBoard().getBoardSpace(9, 6));
        game.handleDragDrop(tileE, game.getBoard().getBoardSpace(9, 7));
        game.handleDragDrop(tileI, game.getBoard().getBoardSpace(9, 9));
        game.handleDragDrop(tileS3, game.getBoard().getBoardSpace(9, 10));
        // SINGLE GAP HORIZONTAL:
        //       S
        //       P
        //     W O R D
        //       T
        // T H E S I S
        assertTrue("SINGLE GAP HORIZONTAL - failed", game.handleConfirmWord());

        Tile tileP2 = new Tile('P');
        Tile tileA = new Tile('A');
        Tile tileS4 = new Tile('S');
        Tile tileS5 = new Tile('S');
        Tile tileS6 = new Tile('S');
        game.handleDragDrop(tileP2, game.getBoard().getBoardSpace(7, 3));
        game.handleDragDrop(tileA, game.getBoard().getBoardSpace(7, 4));
        game.handleDragDrop(tileS4, game.getBoard().getBoardSpace(7, 5));
        game.handleDragDrop(tileS5, game.getBoard().getBoardSpace(7, 6));
        game.handleDragDrop(tileS6, game.getBoard().getBoardSpace(7, 11));
        // MULTIPLE GAP HORIZONTAL:
        //           S
        //           P
        // P A S S W O R D S
        //           T
        // T H E S I S
        assertTrue("MULTIPLE GAP HORIZONTAL - failed", game.handleConfirmWord());
    }

    @Test
    public void testAdjacentPlacement() {
        // TODO: implement adjacent placement validation, as tested below

        ScrabbleModel game = new ScrabbleModel();
        Player player = new Player("TestPlayer");
        game.setPlayers(new java.util.ArrayList<>(java.util.Arrays.asList(player)));

        Tile tileA = new Tile('A');
        Tile tileN = new Tile('N');

        game.handleDragDrop(tileA, game.getBoard().getBoardSpace(7, 7));
        game.handleDragDrop(tileN, game.getBoard().getBoardSpace(7, 8));
        // A N
        assertTrue(game.handleConfirmWord()); // word covers center boardspace played horizontally

        Tile tileT = new Tile('T');
        Tile tileA2 = new Tile('A');
        Tile tileI = new Tile('I');
        Tile tileL = new Tile('L');
        game.handleDragDrop(tileT, game.getBoard().getBoardSpace(7, 9));
        game.handleDragDrop(tileA2, game.getBoard().getBoardSpace(8, 9));
        game.handleDragDrop(tileI, game.getBoard().getBoardSpace(9, 9));
        game.handleDragDrop(tileL, game.getBoard().getBoardSpace(10, 9));
        // TAILING ADJACENT VERTICAL:
        // Form ANT and TAIL
        assertTrue("TAILING ADJACENT VERTICAL - failed", game.handleConfirmWord());

        Tile tileW = new Tile('W');
        Tile tileA3 = new Tile('A');
        Tile tileY = new Tile('Y');
        game.handleDragDrop(tileW, game.getBoard().getBoardSpace(7, 6));
        game.handleDragDrop(tileA3, game.getBoard().getBoardSpace(8, 6));
        game.handleDragDrop(tileY, game.getBoard().getBoardSpace(9, 6));
        // Form want and way
        assertTrue("LEADING ADJACENT VERTICAL - failed", game.handleConfirmWord());

        Tile tileS3 = new Tile('S');
        Tile tileO2 = new Tile('O');
        game.handleDragDrop(tileS3, game.getBoard().getBoardSpace(10, 6));
        game.handleDragDrop(tileO2, game.getBoard().getBoardSpace(10, 7));
        // Form ways and so
        assertTrue("BELOW ADJACENT HORIZONTAL - failed", game.handleConfirmWord());

        Tile tileH = new Tile('h');
        Tile tileI2 = new Tile('i');
        game.handleDragDrop(tileH, game.getBoard().getBoardSpace(6, 7));
        game.handleDragDrop(tileI2, game.getBoard().getBoardSpace(6, 8));
        // Form as follows:
        // h i
        // w a n t
        assertTrue("MULTIPLE ADJACENT HORIZONTAL - failed", game.handleConfirmWord());

        Tile tileI3 = new Tile('I');
        Tile tileT2 = new Tile('T');
        game.handleDragDrop(tileI3, game.getBoard().getBoardSpace(8, 10));
        game.handleDragDrop(tileT2, game.getBoard().getBoardSpace(9, 10));
        // Formed as follows:
        // T
        // A I
        // I T
        // L
        assertTrue("MULTIPLE ADJACENT VERTICAL - failed", game.handleConfirmWord());
    }

    @Test
    public void testFailedDiagonalWordPlacement() {
        ScrabbleModel game = new ScrabbleModel();
        Player player = new Player("TestPlayer");
        game.setPlayers(new java.util.ArrayList<>(java.util.Arrays.asList(player)));

        Tile tileW = new Tile('W');
        Tile tileO = new Tile('O');
        Tile tileR = new Tile('R');
        Tile tileD = new Tile('D');
        game.handleDragDrop(tileW, game.getBoard().getBoardSpace(7, 7));
        game.handleDragDrop(tileO, game.getBoard().getBoardSpace(8, 8));
        game.handleDragDrop(tileR, game.getBoard().getBoardSpace(9, 9));
        game.handleDragDrop(tileD, game.getBoard().getBoardSpace(10, 10));
        // D
        //   R
        //     O
        //       W
        Assert.assertFalse("DIAGONAL PLACEMENT - succeeded", game.handleConfirmWord());
    }

    @Test
    public void testOutOfBoundsWordPlacement() {
        // This should never be possible, changed to test that exception is thrown here
        // to avoid unexpected behavior
        ScrabbleModel game = new ScrabbleModel();
        Player player = new Player("TestPlayer");
        game.setPlayers(new java.util.ArrayList<>(java.util.Arrays.asList(player)));

        Tile tile = new Tile('L');
        assertThrows(IndexOutOfBoundsException.class, () -> game.getBoard().getBoardSpace(16, 16));
    }

    // SCORE
    @Test
    public void testNewGameInitialScore() {
        Player player = new Player("TestPlayer");
        Assert.assertEquals(0, player.getScore());
    }

    @Test
    public void testScoreModifiers() {
        ScrabbleModel game = new ScrabbleModel();
        Player player = new Player("TestPlayer");
        game.setPlayers(new java.util.ArrayList<>(java.util.Arrays.asList(player)));

        // 2x WORD SCORE
        Tile tileW = new Tile('W');
        Tile tileO = new Tile('O');
        Tile tileR = new Tile('R');
        Tile tileD = new Tile('D');
        game.handleDragDrop(tileW, game.getBoard().getBoardSpace(7, 7));
        game.handleDragDrop(tileO, game.getBoard().getBoardSpace(7, 8));
        game.handleDragDrop(tileR, game.getBoard().getBoardSpace(7, 9));
        game.handleDragDrop(tileD, game.getBoard().getBoardSpace(7, 10));
        // W O R D
        // * starting tile is 2x Word Score
        game.handleConfirmWord();
        Assert.assertEquals("CENTER TILE 2x WORD SCORE - failed", (4 + 1 + 1 + 2) * 2, player.getScore());

        // NO MODIFIERS
        Tile tileC = new Tile('C');
        Tile tileO2 = new Tile('O');
        game.handleDragDrop(tileC, game.getBoard().getBoardSpace(5, 10));
        game.handleDragDrop(tileO2, game.getBoard().getBoardSpace(6, 10));
        //       C
        //       O
        // W O R D
        int prevScore = player.getScore(); // bypasses previous faulty tests
        game.handleConfirmWord();
        Assert.assertEquals("NO MODIFIERS - failed", prevScore + (3 + 1 + 2), player.getScore());

        // DOUBLE LETTER SCORE
        Tile tileS = new Tile('S');
        game.handleDragDrop(tileS, game.getBoard().getBoardSpace(7, 11));
        //       C
        //       O
        // W O R D S
        prevScore = player.getScore(); // bypasses previous faulty tests
        game.handleConfirmWord();
        Assert.assertEquals("DOUBLE LETTER SCORE - failed", prevScore + (4 + 1 + 1 + 2 + (1 * 2)), player.getScore());

        // TRIPLE LETTER SCORE
        Tile tileO3 = new Tile('O');
        Tile tileU = new Tile('U');
        Tile tileL = new Tile('L');
        Tile tileD2 = new Tile('D');
        game.handleDragDrop(tileO3, game.getBoard().getBoardSpace(5, 11));
        game.handleDragDrop(tileU, game.getBoard().getBoardSpace(5, 12));
        game.handleDragDrop(tileL, game.getBoard().getBoardSpace(5, 13));
        game.handleDragDrop(tileD2, game.getBoard().getBoardSpace(5, 14));
        //         C O U L D
        //         O
        // W O R D S
        prevScore = player.getScore(); // bypasses previous faulty tests
        game.handleConfirmWord();
        Assert.assertEquals("TRIPLE LETTER SCORE - failed", prevScore + (3 + 1 + 1 + (1 * 3) + 2), player.getScore());

        // TRIPLE WORD SCORE
        Tile tileA = new Tile('A');
        Tile tileD3 = new Tile('D');
        game.handleDragDrop(tileA, game.getBoard().getBoardSpace(6, 14));
        game.handleDragDrop(tileD3, game.getBoard().getBoardSpace(7, 14));
        //       C O U L D
        //       O       A
        // W O R D S     D

        prevScore = player.getScore(); // bypasses previous faulty tests
        game.handleConfirmWord();
        Assert.assertEquals("TRIPLE WORD SCORE - failed", prevScore + ((2 + 1 + 2) * 3), player.getScore());
    }

    @Test
    public void test7TileBonus() {
        ScrabbleModel game = new ScrabbleModel();
        Player player = new Player("TestPlayer");
        game.setPlayers(new java.util.ArrayList<>(java.util.Arrays.asList(player)));

        // Play the word systems
        Tile S1 = new Tile('S');
        Tile Y1 = new Tile('Y');
        Tile S2 = new Tile('S');
        Tile T1 = new Tile('T');
        Tile E1 = new Tile('E');
        Tile M1 = new Tile('M');
        Tile S3 = new Tile('S');

        game.handleDragDrop(S1, game.getBoard().getBoardSpace(7, 7));
        game.handleDragDrop(Y1, game.getBoard().getBoardSpace(7, 8));
        game.handleDragDrop(S2, game.getBoard().getBoardSpace(7, 9));
        game.handleDragDrop(T1, game.getBoard().getBoardSpace(7, 10));
        game.handleDragDrop(E1, game.getBoard().getBoardSpace(7, 11));
        game.handleDragDrop(M1, game.getBoard().getBoardSpace(7, 12));
        game.handleDragDrop(S3, game.getBoard().getBoardSpace(7, 13));
        game.handleConfirmWord();
        Assert.assertEquals(((1 + 4 + 1 + 1 + (1 * 2) + 3 + 1) * 2) + 50, player.getScore());

    }

    @Test
    public void testGameOverPlayedOut() {
        ScrabbleModel game = new ScrabbleModel();
        Player player1 = new Player("TestPlayer");
        Player player2 = new Player("TestPlayer2");
        Player player3 = new Player("TestPlayer3");
        game.setPlayers(new java.util.ArrayList<>(java.util.Arrays.asList(player1, player2, player3)));
        while (!game.getCurPlayer().equals(player1)) { // Make sure player 1 is current player
            game.switchCurPlayer();
        }
        while (game.getBag().getNumTilesLeft() > 0) { // Empty Bag
            game.getBag().grabTile();
        }

        while (player1.tileCount() > 0) { // Empty player 1 hand
            player1.getHand().removeFirst();
        }

        Tile A1 = new Tile('A');
        player1.addTile(A1);
        Tile R1 = new Tile('R');
        player1.addTile(R1);
        Tile I1 = new Tile('I');
        player1.addTile(I1);
        Tile S1 = new Tile('S');
        player1.addTile(S1);
        Tile I2 = new Tile('I');
        player1.addTile(I2);
        Tile N1 = new Tile('N');
        player1.addTile(N1);
        Tile G1 = new Tile('G');
        player1.addTile(G1);

        while (player2.tileCount() > 0) { // Empty player 2 hand
            player2.getHand().removeFirst();
        }

        Tile D1 = new Tile('D');
        player2.addTile(D1);
        Tile Z1 = new Tile('Z');
        player2.addTile(Z1);
        Tile S2 = new Tile('S');
        player2.addTile(S2);

        while (player3.tileCount() > 0) {
            player3.getHand().removeFirst();
        }

        Tile A2 = new Tile('A');
        player3.addTile(A2);

        for (int i = 0; i < 7; i++) { // Place all player 1 tiles sequentially in a row
            game.handleDragDrop(player1.getHand().removeFirst(), game.getBoard().getBoardSpace(7, i + 5));
        }

        assertTrue(game.handleConfirmWord());
        int theorteticalScore = 2 * (1 + 1 + 1 + 1 + 1 + 1 + 2 * 2) + 50;
        assertEquals(theorteticalScore, player1.getScore());

        player2.increaseScore(50);
        player3.increaseScore(1);
        game.checkGameEnd();
        theorteticalScore += 2 + 10 + 1 + 1;
        assertEquals(theorteticalScore, player1.getScore());
        assertEquals(50 - 2 - 10 - 1, player2.getScore());
        assertEquals(1 - 1, player3.getScore());
    }
}
