import java.io.*;
import java.util.*;

/**
 * Represents a word placed on a board in Scrabble
 *
 * @author Kyle Foisy
 */
public class Word implements Serializable {
    private final String word;
    private ArrayList<Tile> tiles;
    private ArrayList<BoardSpace> spaces;

    public enum Age {
        OLD, NEW
    }; // To be used in milestone 3 & 4

    private ArrayList<Age> ages; // To be used in milestone 3 & 4
    private static HashSet<String> scrabbleDictionary = loadDictionary();
    private static final ArrayList<String> dictionary = new ArrayList<String>();

    /**
     * The constructor for a word.
     *
     * @param spaces The ordered BoardSpaces that form the word
     */
    public Word(ArrayList<BoardSpace> spaces) {
        this.spaces = spaces;
        this.tiles = new ArrayList<>();
        this.ages = new ArrayList<>();
        StringBuilder temp = new StringBuilder();

        if (scrabbleDictionary == null) {
            scrabbleDictionary = loadDictionary();
        }

        for (BoardSpace space : spaces) {
            tiles.add(space.getTile());
        }
        for (Tile tile : tiles) {
            temp.append(tile.getLetter());
            if (tile.isPlaced()) {
                ages.add(Age.OLD);
            } else {
                ages.add(Age.NEW);
            }
        }
        word = temp.toString();
    }

    public String getWord() {
        return word;
    }

    /**
     * Sums the total score of this word.
     * To be updated for milestone 3.
     *
     * @return The total score of this word
     */
    public int getWordScore(

    ) {
        int score = 0;
        for (int i = 0; i < tiles.size(); i++) { // For tile that forms word, get score
            if ((ages.get(i) == Age.NEW) && (spaces.get(i).getModifier() == BoardSpace.Modifier.LS2X)) { // Check if
                                                                                                         // this tile is
                                                                                                         // new and is
                                                                                                         // placed on 2X
                                                                                                         // space
                score += tiles.get(i).getScore() * 2; // Add 2x score
            } else if ((ages.get(i) == Age.NEW) && (spaces.get(i).getModifier() == BoardSpace.Modifier.LS3X)) {// Check
                                                                                                               // if
                                                                                                               // this
                                                                                                               // tile
                                                                                                               // is new
                                                                                                               // and is
                                                                                                               // placed
                                                                                                               // on 3X
                                                                                                               // space
                score += tiles.get(i).getScore() * 3; // Add 3x score
            } else { // Just add tile score to word
                score += tiles.get(i).getScore();
            }
        }

        for (int i = 0; i < tiles.size(); i++) { // For tile that forms word, check for 2X and 3X word scores
            if ((ages.get(i) == Age.NEW) && ((spaces.get(i).getModifier() == BoardSpace.Modifier.WS2X)
                    || (spaces.get(i).getModifier() == BoardSpace.Modifier.START))) { // If tile placed this turn, and
                                                                                      // we have 2X word modifier or
                                                                                      // starting square
                score *= 2; // Multiply score by 2
            } else if ((ages.get(i) == Age.NEW) && (spaces.get(i).getModifier() == BoardSpace.Modifier.WS3X)) { // If
                                                                                                                // tile
                                                                                                                // placed
                                                                                                                // this
                                                                                                                // turn,
                                                                                                                // and
                                                                                                                // we
                                                                                                                // have
                                                                                                                // 3X
                                                                                                                // word
                                                                                                                // modifier
                score *= 3; // Multiply score by 3
            }
        }

        return score;
    }

    /**
     * Checks if the attempted words exists within Scrabble dictionary
     *
     * @return True if the dictionary has the words.
     */
    public Boolean isValid() {
        if (scrabbleDictionary == null) {
            System.out.println("Dictionary is not loaded.");
            return false;
        }
        return scrabbleDictionary.contains(word.toUpperCase());
    }

    /**
     * Checks ages and returns true if this word contains at least 1 previously
     * placed tile, false otherwise
     *
     * @return true if this word contains at least 1 previously placed tile, false
     *         otherwise
     */
    public Boolean hasPreviouslyPlacedTile() {
        return ages.contains(Age.OLD);
    }

    /**
     * Loads scrabble dictionary
     */
    private static HashSet<String> loadDictionary() {
        HashSet<String> dictionary = new HashSet<>();
        try (InputStream in = Word.class.getResourceAsStream("/scrabbleDictionary.txt");
             BufferedReader reader = new BufferedReader(new InputStreamReader(in))) {
            String word;
            while ((word = reader.readLine()) != null) {
                dictionary.add(word.toUpperCase());
            }

            reader.close();
            return dictionary;

        }
        catch(IOException e){
            System.out.println("Unable to load scrabble dictionary");
            return null;
        }
    }

    /**
     * Returns a random word for an AI player to use.
     *
     * @return A random word.
     */
    public static String getRandomWord() {
        // TODO: fix loading dictionary on every AI player turn
        // static makes it so we cant access dictionary
        if (scrabbleDictionary == null) {
            scrabbleDictionary = loadDictionary();
        }
        int idx = new java.util.Random().nextInt(scrabbleDictionary.size());
        return new ArrayList<>(scrabbleDictionary).get(idx); // convert to list to get word
    }
}
