import java.io.Serializable;
import java.util.ArrayList;

public class AIPlayer extends Player implements Serializable {
    private ScrabbleModel model; // needed to update game state

    /**
     * A constructor for an AI player.
     *
     * @param playerName name of the AI player
     */
    public AIPlayer(String playerName, ScrabbleModel model) {
        super(playerName);
        this.model = model;
    }

    /**
     * The AI player plays its turn.
     */
    public void handleTurn() {
        ScrabbleView.popUp("AI TURN - " + this.getName(), this.getName() + "'s turn.");
        handlePlay(); // attempts to play a word
    }

    /**
     * handle AI placing a word.
     */
    private void handlePlay() {
        if (model.getBoard().getPlacedTiles().size() == 0) {
            // skips playing first
            handlePass();
            return;
        }

        // attempts 2000 random words
        int attempts = 2000;
        String word = "";

        while (attempts-- > 0) {
            word = Word.getRandomWord(); // get random word

            if (true) {
                // CONSOLE FEEDBACK
                ArrayList<Character> handTiles = new ArrayList<>();
                this.getHand().forEach(tile -> handTiles.add(tile.getLetter()));
                System.out.println(
                        "AI - Attempting \"" + word + "\"" + (word.length() < 6 ? "\t" : "") + "\t attempt: "
                                + (2000 - attempts) + "\t hand: "
                                + handTiles);
            }

            if (word.length() <= 1)
                continue; // avoids 1 letter words, attempt next random word

            // CHECK: tiles needed available TODO MIXED BOTH STATES HANDS?
            if (!hasTilesInHand(word))
                continue; // missing tiles in hand, attempt next random word

            char linkingChar = getLinkingChar(word);

            if (!model.getBoard().hasTilePlaced(linkingChar))
                continue; // no linking char on board, attempt next random word

            // CHECK: find placement
            System.out.println("\tATTEMPTING PLACEMENT");
            int idx = word.indexOf(linkingChar);
            int leading = idx; // chars leading linking char
            int tailing = word.length() - idx - 1; // chars tailing linking char

            for (BoardSpace boardspace : getLinkingBoardspaces(linkingChar)) {
                // test all linking placements available
                int row = boardspace.getRow();
                int col = boardspace.getCol();

                // try placing horizontally
                if (placeHorizontally(row, col, word, leading, idx, tailing))
                    break; // word placed
                else
                    model.handleRemovePlacedTiles();

                // try placing vertically
                if (placeVertically(row, col, word, leading, idx, tailing))
                    break; // word placed
                else
                    model.handleRemovePlacedTiles();
            }

            model.updateViews();

            if (model.handleConfirmWord()) {
                // on success
                ScrabbleView.popUp("AI TURN - Played Word",
                        this.getName() + " played \"" + word.toUpperCase() + "\"");
                model.handleEndTurn();
                return;
            } else {
                model.handleRemovePlacedTiles();
            }
        }
        // on fail
        handleExchange();
    }

    /**
     * helper for handlePlay
     * checks if the tiles needed to write a word are in the AI Player's hand
     * 
     * @param word to be played
     * @return whether tiles are available or not
     */
    private boolean hasTilesInHand(String word) {
        ArrayList<Character> wordChars = new ArrayList<>();
        for (char c : word.toCharArray())
            wordChars.add(c);

        for (char c : word.toCharArray()) {
            if (hasTile(c))
                wordChars.remove((Character) c);
        }

        return wordChars.size() <= 1; // no more than missing 1 tile
    }

    /**
     * helper for handlePlay
     * finds the letter the AI Player need to locate on the board
     * 
     * @param word to be played
     * @return letter of missing/linking tile
     */
    public char getLinkingChar(String word) {
        ArrayList<Character> wordChars = new ArrayList<>();
        for (char c : word.toCharArray())
            wordChars.add(c);

        for (char c : word.toCharArray()) {
            if (hasTile(c))
                wordChars.remove((Character) c);
            if (wordChars.size() <= 1)
                break; // keep 1 linking char
        }

        return wordChars.removeFirst();
    }

    /**
     * helper for handlePlay
     * finds all linking char boardspaces currently on the board
     * 
     * @param linkingChar to be looked up on the board
     * @return ArrayList of Boardspaces to attempt linking a word to
     */
    private ArrayList<BoardSpace> getLinkingBoardspaces(char linkingChar) {
        ArrayList<BoardSpace> linkingBoardspaces = new ArrayList<>();
        for (BoardSpace boardspace : model.getBoard().getPlacedTiles()) {
            if (boardspace.getTile().getLetter() == linkingChar) {
                linkingBoardspaces.add(boardspace);
            }
        }
        return linkingBoardspaces;
    }

    /**
     * helper for handlePlay
     * attempts to play the word horizontally, linking with a given boardspace
     * 
     * @param row
     * @param col
     * @param word
     * @param leading
     * @param idx
     * @param tailing
     * @return whether placement was successful or not
     */
    private boolean placeHorizontally(int row, int col, String word, int leading, int idx, int tailing) {
        if (Board.withinBounds(row, col - leading) && Board.withinBounds(row, col + tailing)) {
            int curCharIdx = 0;

            for (int i = col - leading; i <= col + tailing; i++, curCharIdx++) {
                if (curCharIdx == idx)
                    continue; // skip linking char

                BoardSpace curSpace = model.getBoard().getBoardSpace(row, i);

                if (curSpace.hasTile())
                    return false; // occupied tile

                Tile placedTile = this.removeTile(word.charAt(curCharIdx));

                if (placedTile == null)
                    return false; // avoid placing null tile bug

                model.getBoard().placeTile(placedTile, curSpace);
            }
        } else {
            return false; // stretchs outside bounds
        }

        return true; // word placed
    }

    /**
     * helper for handlePlay
     * attempts to play the word vertically, linking with a given boardspace
     * 
     * @param row
     * @param col
     * @param word
     * @param leading
     * @param idx
     * @param tailing
     * @return whether placement was successful or not
     */
    private boolean placeVertically(int row, int col, String word, int leading, int idx, int tailing) {
        if (Board.withinBounds(row - leading, col) && Board.withinBounds(row + tailing, col)) {
            int curCharIdx = 0;

            for (int i = row - leading; i <= row + tailing; i++, curCharIdx++) {
                if (curCharIdx == idx)
                    continue; // skip linking char

                BoardSpace curSpace = model.getBoard().getBoardSpace(i, col);

                if (curSpace.hasTile())
                    return false; // occupied tile

                Tile placedTile = this.removeTile(word.charAt(curCharIdx));

                if (placedTile == null)
                    return false; // avoid placing null tile bug

                model.getBoard().placeTile(placedTile, curSpace);

            }
        } else {
            return false; // stretchs outside bounds
        }

        return true; // word placed
    }

    /**
     * handle AI exchanging letters.
     */
    private void handleExchange() {
        // choose random tiles in hand
        ArrayList<Tile> chosenTiles = new ArrayList<>();
        ArrayList<Tile> hand = this.getHand();

        if (!hand.isEmpty()) {
            chosenTiles.add(hand.get(0)); // first tile is always exchanged

            for (int i = 1; i < hand.size(); i++) {
                if (Math.random() < 0.2) {
                    // 20% chance of exchanging additional tiles
                    chosenTiles.add(hand.get(i));
                }
            }
        }

        // trade out chosen tiles
        if (model.handleExchange(chosenTiles)) {
            // on success
            ScrabbleView.popUp("AI TURN - Exchanged Tiles",
                    this.getName() + " exchanged " + chosenTiles.size() + " tile" + (chosenTiles.size() > 1 ? "s."
                            : "."));
            model.handleEndTurn();
        } else {
            // on fail
            handlePass();
        }
    }

    /**
     * handle AI passing its turn.
     */
    private void handlePass() {
        ScrabbleView.popUp("AI TURN - Passed Turn", this.getName() + " skipped their turn.");
        model.handlePassTurn();
    }

    /**
     * Creates a copy of the current Player.
     *
     * @return A copy of the current Player.
     */
    public AIPlayer createCopy(ScrabbleModel model) {
        AIPlayer copy = new AIPlayer(this.getName(), model);

        for (Tile tile : this.getHand()) {
            copy.addTile(new Tile(tile.getLetter()));
        }

        copy.increaseScore(this.getScore());

        return copy;
    }
}
