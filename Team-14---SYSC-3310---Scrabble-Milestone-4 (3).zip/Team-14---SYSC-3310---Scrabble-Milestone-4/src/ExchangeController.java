import javax.swing.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.ArrayList;

/**
 * Handles user inputs for ExchangeView.
 *
 * @author Kyle Foisy
 */
public class ExchangeController implements ActionListener {
    ArrayList<Tile> hand;
    boolean[] selectedTiles;
    ScrabbleModel model;
    ExchangeView view;

    /**
     * The constructor for this class.
     * Written by Kyle Foisy.
     *
     * @param hand The current player's hand.
     * @param model The scrabble model
     * @param view The corresponding exchange view for this controller
     */
    ExchangeController(ArrayList<Tile> hand, ScrabbleModel model, ExchangeView view) {
        this.hand = hand;
        this.model = model;
        this.view = view;
        selectedTiles = new boolean[hand.size()];
        for (int i = 0; i < 7; i++) {
            selectedTiles[i] = false;
        }
    }

    @Override
    public void actionPerformed(ActionEvent e) {
        if (e.getActionCommand().equals("confirm")) { //Player is confirming tile select
            handleConfirm();
        } else if (e.getActionCommand().equals("cancel")) { //Player cancels select
            view.dispose();
        } else { //Toggle selected tile for button pressed
            int i = Integer.parseInt(e.getActionCommand());
            selectedTiles[i] = !selectedTiles[i];
            view.updateButtons(selectedTiles);
        }
    }

    /**
     * Invoked when player presses Confirm.
     * Organizes selected player tiles to pass to model.
     * Does nothing if there are no selected tiles.
     *
     * Written by Kyle Foisy.
     */
    private void handleConfirm() {
        ArrayList<Tile> tiles = new ArrayList<>();
        for (int i = 0; i < selectedTiles.length; i++) {
            if (selectedTiles[i]) {
                tiles.add(hand.get(i));
            }
        }
        if (tiles.isEmpty()) {
            JOptionPane.showMessageDialog(new JFrame(), "No tiles selected!", null, JOptionPane.WARNING_MESSAGE);
            return;
        } else {
            view.dispose();
            model.handleExchange(tiles);
        }
    }
}
