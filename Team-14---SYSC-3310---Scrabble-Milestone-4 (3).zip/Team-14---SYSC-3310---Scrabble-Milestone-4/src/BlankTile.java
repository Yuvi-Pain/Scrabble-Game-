import java.io.Serializable;

public class BlankTile extends Tile implements Serializable {
    /**
     * A constructor for a blank tile in scrabble.
     *
     */
    public BlankTile() {
        super(' ');
    }

    public void setLetter(char letter) {
        this.letter = Character.toUpperCase(letter);
    }

    public void clearLetter() {
        this.setLetter(' ');
    }
}
