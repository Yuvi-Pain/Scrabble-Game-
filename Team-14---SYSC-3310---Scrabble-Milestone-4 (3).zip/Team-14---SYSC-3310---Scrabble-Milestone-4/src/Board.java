import java.io.Serializable;
import java.util.*;

/**
 * A class representing a Scrabble board.
 *
 * @author Kyle Foisy, Peter McComb, Yuvraj Bains
 * @version Oct 20
 */
public class Board implements Serializable {
    private ArrayList<ArrayList<BoardSpace>> board;
    private ArrayList<Word> curWords;
    private ArrayList<BoardSpace> curTilePlacements;
    public int BOARDSIZE = 15;
    private ArrayList<BoardSpace> placedTiles;

    /**
     * A constructor for the board in scrabble. Creates all the BoardSpaces required
     * to fill the 15x15
     * grid board for scrabble.
     */
    public Board() {
        board = new ArrayList<>(15);
        curWords = new ArrayList<>();
        curTilePlacements = new ArrayList<>();
        placedTiles = new ArrayList<>();

        ArrayList<BoardSpace> row1 = new ArrayList<>(15);
        ArrayList<BoardSpace> row2 = new ArrayList<>(15);
        ArrayList<BoardSpace> row3 = new ArrayList<>(15);
        ArrayList<BoardSpace> row4 = new ArrayList<>(15);
        ArrayList<BoardSpace> row5 = new ArrayList<>(15);
        ArrayList<BoardSpace> row6 = new ArrayList<>(15);
        ArrayList<BoardSpace> row7 = new ArrayList<>(15);
        ArrayList<BoardSpace> row8 = new ArrayList<>(15);
        ArrayList<BoardSpace> row9 = new ArrayList<>(15);
        ArrayList<BoardSpace> row10 = new ArrayList<>(15);
        ArrayList<BoardSpace> row11 = new ArrayList<>(15);
        ArrayList<BoardSpace> row12 = new ArrayList<>(15);
        ArrayList<BoardSpace> row13 = new ArrayList<>(15);
        ArrayList<BoardSpace> row14 = new ArrayList<>(15);
        ArrayList<BoardSpace> row15 = new ArrayList<>(15);

        // row 1 & 15
        row1.add(new BoardSpace(BoardSpace.Modifier.WS3X));
        row15.add(new BoardSpace(BoardSpace.Modifier.WS3X));
        for (int i = 0; i < 2; i++) {
            row1.add(new BoardSpace(BoardSpace.Modifier.NONE));
            row15.add(new BoardSpace(BoardSpace.Modifier.NONE));
        }
        row1.add(new BoardSpace(BoardSpace.Modifier.LS2X));
        row15.add(new BoardSpace(BoardSpace.Modifier.LS2X));
        for (int i = 0; i < 3; i++) {
            row1.add(new BoardSpace(BoardSpace.Modifier.NONE));
            row15.add(new BoardSpace(BoardSpace.Modifier.NONE));
        }
        row1.add(new BoardSpace(BoardSpace.Modifier.WS3X));
        row15.add(new BoardSpace(BoardSpace.Modifier.WS3X));
        for (int i = 0; i < 3; i++) {
            row1.add(new BoardSpace(BoardSpace.Modifier.NONE));
            row15.add(new BoardSpace(BoardSpace.Modifier.NONE));
        }
        row1.add(new BoardSpace(BoardSpace.Modifier.LS2X));
        row15.add(new BoardSpace(BoardSpace.Modifier.LS2X));
        for (int i = 0; i < 2; i++) {
            row1.add(new BoardSpace(BoardSpace.Modifier.NONE));
            row15.add(new BoardSpace(BoardSpace.Modifier.NONE));
        }
        row1.add(new BoardSpace(BoardSpace.Modifier.WS3X));
        row15.add(new BoardSpace(BoardSpace.Modifier.WS3X));

        // row 2 & 14
        row2.add(new BoardSpace(BoardSpace.Modifier.NONE));
        row14.add(new BoardSpace(BoardSpace.Modifier.NONE));
        row2.add(new BoardSpace(BoardSpace.Modifier.WS2X));
        row14.add(new BoardSpace(BoardSpace.Modifier.WS2X));
        for (int i = 0; i < 3; i++) {
            row2.add(new BoardSpace(BoardSpace.Modifier.NONE));
            row14.add(new BoardSpace(BoardSpace.Modifier.NONE));
        }
        row2.add(new BoardSpace(BoardSpace.Modifier.LS3X));
        row14.add(new BoardSpace(BoardSpace.Modifier.LS3X));
        for (int i = 0; i < 3; i++) {
            row2.add(new BoardSpace(BoardSpace.Modifier.NONE));
            row14.add(new BoardSpace(BoardSpace.Modifier.NONE));
        }
        row2.add(new BoardSpace(BoardSpace.Modifier.LS3X));
        row14.add(new BoardSpace(BoardSpace.Modifier.LS3X));
        for (int i = 0; i < 3; i++) {
            row2.add(new BoardSpace(BoardSpace.Modifier.NONE));
            row14.add(new BoardSpace(BoardSpace.Modifier.NONE));
        }
        row2.add(new BoardSpace(BoardSpace.Modifier.WS2X));
        row14.add(new BoardSpace(BoardSpace.Modifier.WS2X));
        row2.add(new BoardSpace(BoardSpace.Modifier.NONE));
        row14.add(new BoardSpace(BoardSpace.Modifier.NONE));

        // row 3 & 13
        for (int i = 0; i < 2; i++) {
            row3.add(new BoardSpace(BoardSpace.Modifier.NONE));
            row13.add(new BoardSpace(BoardSpace.Modifier.NONE));
        }
        row3.add(new BoardSpace(BoardSpace.Modifier.WS2X));
        row13.add(new BoardSpace(BoardSpace.Modifier.WS2X));
        for (int i = 0; i < 3; i++) {
            row3.add(new BoardSpace(BoardSpace.Modifier.NONE));
            row13.add(new BoardSpace(BoardSpace.Modifier.NONE));
        }
        row3.add(new BoardSpace(BoardSpace.Modifier.LS2X));
        row13.add(new BoardSpace(BoardSpace.Modifier.LS2X));
        row3.add(new BoardSpace(BoardSpace.Modifier.NONE));
        row13.add(new BoardSpace(BoardSpace.Modifier.NONE));
        row3.add(new BoardSpace(BoardSpace.Modifier.LS2X));
        row13.add(new BoardSpace(BoardSpace.Modifier.LS2X));
        for (int i = 0; i < 3; i++) {
            row3.add(new BoardSpace(BoardSpace.Modifier.NONE));
            row13.add(new BoardSpace(BoardSpace.Modifier.NONE));
        }
        row3.add(new BoardSpace(BoardSpace.Modifier.WS2X));
        row13.add(new BoardSpace(BoardSpace.Modifier.WS2X));
        for (int i = 0; i < 2; i++) {
            row3.add(new BoardSpace(BoardSpace.Modifier.NONE));
            row13.add(new BoardSpace(BoardSpace.Modifier.NONE));
        }

        // row 4 & 12
        row4.add(new BoardSpace(BoardSpace.Modifier.LS2X));
        row12.add(new BoardSpace(BoardSpace.Modifier.LS2X));
        for (int i = 0; i < 2; i++) {
            row4.add(new BoardSpace(BoardSpace.Modifier.NONE));
            row12.add(new BoardSpace(BoardSpace.Modifier.NONE));
        }
        row4.add(new BoardSpace(BoardSpace.Modifier.WS2X));
        row12.add(new BoardSpace(BoardSpace.Modifier.WS2X));
        for (int i = 0; i < 3; i++) {
            row4.add(new BoardSpace(BoardSpace.Modifier.NONE));
            row12.add(new BoardSpace(BoardSpace.Modifier.NONE));
        }
        row4.add(new BoardSpace(BoardSpace.Modifier.LS2X));
        row12.add(new BoardSpace(BoardSpace.Modifier.LS2X));
        for (int i = 0; i < 3; i++) {
            row4.add(new BoardSpace(BoardSpace.Modifier.NONE));
            row12.add(new BoardSpace(BoardSpace.Modifier.NONE));
        }
        row4.add(new BoardSpace(BoardSpace.Modifier.WS2X));
        row12.add(new BoardSpace(BoardSpace.Modifier.WS2X));
        for (int i = 0; i < 2; i++) {
            row4.add(new BoardSpace(BoardSpace.Modifier.NONE));
            row12.add(new BoardSpace(BoardSpace.Modifier.NONE));
        }
        row4.add(new BoardSpace(BoardSpace.Modifier.LS2X));
        row12.add(new BoardSpace(BoardSpace.Modifier.LS2X));

        // row 5 & 11
        for (int i = 0; i < 4; i++) {
            row5.add(new BoardSpace(BoardSpace.Modifier.NONE));
            row11.add(new BoardSpace(BoardSpace.Modifier.NONE));
        }
        row5.add(new BoardSpace(BoardSpace.Modifier.WS2X));
        row11.add(new BoardSpace(BoardSpace.Modifier.WS2X));
        for (int i = 0; i < 5; i++) {
            row5.add(new BoardSpace(BoardSpace.Modifier.NONE));
            row11.add(new BoardSpace(BoardSpace.Modifier.NONE));
        }
        row5.add(new BoardSpace(BoardSpace.Modifier.WS2X));
        row11.add(new BoardSpace(BoardSpace.Modifier.WS2X));
        for (int i = 0; i < 4; i++) {
            row5.add(new BoardSpace(BoardSpace.Modifier.NONE));
            row11.add(new BoardSpace(BoardSpace.Modifier.NONE));
        }

        // row 6 & 10
        row6.add(new BoardSpace(BoardSpace.Modifier.NONE));
        row10.add(new BoardSpace(BoardSpace.Modifier.NONE));
        row6.add(new BoardSpace(BoardSpace.Modifier.LS3X));
        row10.add(new BoardSpace(BoardSpace.Modifier.LS3X));
        for (int i = 0; i < 3; i++) {
            row6.add(new BoardSpace(BoardSpace.Modifier.NONE));
            row10.add(new BoardSpace(BoardSpace.Modifier.NONE));
        }
        row6.add(new BoardSpace(BoardSpace.Modifier.LS3X));
        row10.add(new BoardSpace(BoardSpace.Modifier.LS3X));
        for (int i = 0; i < 3; i++) {
            row6.add(new BoardSpace(BoardSpace.Modifier.NONE));
            row10.add(new BoardSpace(BoardSpace.Modifier.NONE));
        }
        row6.add(new BoardSpace(BoardSpace.Modifier.LS3X));
        row10.add(new BoardSpace(BoardSpace.Modifier.LS3X));
        for (int i = 0; i < 3; i++) {
            row6.add(new BoardSpace(BoardSpace.Modifier.NONE));
            row10.add(new BoardSpace(BoardSpace.Modifier.NONE));
        }
        row6.add(new BoardSpace(BoardSpace.Modifier.LS3X));
        row10.add(new BoardSpace(BoardSpace.Modifier.LS3X));
        row6.add(new BoardSpace(BoardSpace.Modifier.NONE));
        row10.add(new BoardSpace(BoardSpace.Modifier.NONE));

        // row 7 & 9
        for (int i = 0; i < 2; i++) {
            row7.add(new BoardSpace(BoardSpace.Modifier.NONE));
            row9.add(new BoardSpace(BoardSpace.Modifier.NONE));
        }
        row7.add(new BoardSpace(BoardSpace.Modifier.LS2X));
        row9.add(new BoardSpace(BoardSpace.Modifier.LS2X));
        for (int i = 0; i < 3; i++) {
            row7.add(new BoardSpace(BoardSpace.Modifier.NONE));
            row9.add(new BoardSpace(BoardSpace.Modifier.NONE));
        }
        row7.add(new BoardSpace(BoardSpace.Modifier.LS2X));
        row9.add(new BoardSpace(BoardSpace.Modifier.LS2X));
        row7.add(new BoardSpace(BoardSpace.Modifier.NONE));
        row9.add(new BoardSpace(BoardSpace.Modifier.NONE));
        row7.add(new BoardSpace(BoardSpace.Modifier.LS2X));
        row9.add(new BoardSpace(BoardSpace.Modifier.LS2X));
        for (int i = 0; i < 3; i++) {
            row7.add(new BoardSpace(BoardSpace.Modifier.NONE));
            row9.add(new BoardSpace(BoardSpace.Modifier.NONE));
        }
        row7.add(new BoardSpace(BoardSpace.Modifier.LS2X));
        row9.add(new BoardSpace(BoardSpace.Modifier.LS2X));
        for (int i = 0; i < 2; i++) {
            row7.add(new BoardSpace(BoardSpace.Modifier.NONE));
            row9.add(new BoardSpace(BoardSpace.Modifier.NONE));
        }

        // row 8
        row8.add(new BoardSpace(BoardSpace.Modifier.WS3X));
        for (int i = 0; i < 2; i++) {
            row8.add(new BoardSpace(BoardSpace.Modifier.NONE));
        }
        row8.add(new BoardSpace(BoardSpace.Modifier.LS2X));
        for (int i = 0; i < 3; i++) {
            row8.add(new BoardSpace(BoardSpace.Modifier.NONE));
        }
        row8.add(new BoardSpace(BoardSpace.Modifier.START));
        for (int i = 0; i < 3; i++) {
            row8.add(new BoardSpace(BoardSpace.Modifier.NONE));
        }
        row8.add(new BoardSpace(BoardSpace.Modifier.LS2X));
        for (int i = 0; i < 2; i++) {
            row8.add(new BoardSpace(BoardSpace.Modifier.NONE));
        }
        row8.add(new BoardSpace(BoardSpace.Modifier.WS3X));

        board.add(row1);
        board.add(row2);
        board.add(row3);
        board.add(row4);
        board.add(row5);
        board.add(row6);
        board.add(row7);
        board.add(row8);
        board.add(row9);
        board.add(row10);
        board.add(row11);
        board.add(row12);
        board.add(row13);
        board.add(row14);
        board.add(row15);

        for (int i = 0; i < board.size(); i++) {
            for (int j = 0; j < board.get(i).size(); j++) {
                board.get(i).get(j).setCol(j);
                board.get(i).get(j).setRow(i);
            }
        }
    }

    /**
     *
     */
    public Board(String[][] boardData) {
        board = new ArrayList<>(15);
        curWords = new ArrayList<>();
        curTilePlacements = new ArrayList<>();
        placedTiles = new ArrayList<>();

        for (int i = 0; i < boardData.length; i++) {
            ArrayList<BoardSpace> row = new ArrayList<>();
            for (int j = 0; j < boardData[i].length; j++) {
                if (i == 7 && j == 7) {
                    row.add(new BoardSpace(BoardSpace.Modifier.START));
                } else if (boardData[i][j].equals("DL")) {
                    row.add(new BoardSpace(BoardSpace.Modifier.LS2X));
                } else if (boardData[i][j].equals("TL")) {
                    row.add(new BoardSpace(BoardSpace.Modifier.LS3X));
                } else if (boardData[i][j].equals("DW")) {
                    row.add(new BoardSpace(BoardSpace.Modifier.WS2X));
                } else if (boardData[i][j].equals("TW")) {
                    row.add(new BoardSpace(BoardSpace.Modifier.WS3X));
                } else {
                    row.add(new BoardSpace(BoardSpace.Modifier.NONE));
                }
            }
            this.board.add(row);
        }

        // set boardspace coordinates
        for (int i = 0; i < board.size(); i++) {
            for (int j = 0; j < board.get(i).size(); j++) {
                board.get(i).get(j).setCol(j);
                board.get(i).get(j).setRow(i);
            }
        }
    }

    /**
     * Tests if provided [row, col] are within board's bounds.
     *
     * @param row of requested boardspace
     * @param col column of requested boardspace
     */
    public static boolean withinBounds(int row, int col) {
        return row >= 0 && row < 15 && col >= 0 && col < 15;
    }

    /**
     * Tries to place a given tile on the given boardspace.
     *
     * @param tile The tile to be placed
     * @param col  The column of the boardspace to be placed in
     * @param row  The row of the boardspace to be placed in
     *
     * @return True if the tile was placed, false otherwise
     */
    public boolean placeTile(Tile tile, int row, int col) {
        BoardSpace boardspace = getBoardSpace(row, col);

        if (boardspace.hasTile()) {
            return false;
        } else {
            boardspace.setTile(tile);
            curTilePlacements.add(boardspace);
            return true;
        }
    }

    /**
     * Overload function that tries to place a given tile on the given boardspace.
     *
     * @param tile       The tile to be placed
     * @param boardSpace The boardspace to be placed in
     *
     * @return True if the tile was placed, false otherwise
     */
    public boolean placeTile(Tile tile, BoardSpace boardSpace) {
        if (boardSpace.hasTile()) {
            return false;
        } else {
            boardSpace.setTile(tile);
            curTilePlacements.add(boardSpace);
            return true;
        }
    }

    /**
     * Determines whether the currently placed tiles are inline with each other.
     *
     * @return A string that describes the orientation of the word
     */
    public String areInline() {
        boolean sameCol = true;
        boolean sameRow = true;

        if (curTilePlacements.isEmpty()) {
            return "invalid";
        } else if (curTilePlacements.size() == 1) {
            return "1";
        }

        int col = curTilePlacements.getFirst().getCol();
        int row = curTilePlacements.getFirst().getRow();

        for (BoardSpace space : curTilePlacements) {
            if (space.getCol() != col) {
                sameCol = false;
            }
            if (space.getRow() != row) {
                sameRow = false;
            }
        }
        if (sameCol) {
            return "col";
        } else if (sameRow) {
            return "row";
        } else {
            return "invalid";
        }
    }

    /**
     * Finds a vertical word created by the current placed letters, if the word
     * exists and adds it
     * to the list of words formed.
     *
     * Checks if all current tile placements form this word. If they do not, does
     * not create a word and returns
     * false.
     *
     * @return True if all placed letters form a word, false otherwise.
     */
    public boolean findVertWord() {
        BoardSpace curTile = curTilePlacements.getFirst();
        int row = curTile.getRow();
        int col = curTile.getCol();

        ArrayList<BoardSpace> spaces = getVertWord(row, col, curTile); // List of spaces making up word

        // Check if there is a placed tile that is missing from this list of spaces
        for (BoardSpace space : curTilePlacements) {
            // If a placed tile is missing, placement invalid
            if (!spaces.contains(space)) {
                return false;
            }
        }

        // If main word has fewer tiles than all placed tiles, return false
        // Prevents disjointed plays
        if (spaces.size() < curTilePlacements.size()) {
            return false;
        }

        // Add word to list of words
        curWords.add(new Word(spaces));
        return true;
    }

    /**
     * Finds all related vertical words formed from current tile placements.
     */
    public void findVertWords() {
        int row;
        int col;
        for (BoardSpace space : curTilePlacements) {
            row = space.getRow();
            col = space.getCol();
            ArrayList<BoardSpace> spaces = getVertWord(row, col, space); // List of spaces making up word

            if (spaces.size() > 1) {
                curWords.add(new Word(spaces));
            }
        }
    }

    /**
     * Extracts a list of tiles that are vertically adjacent given a starting
     * BoardSpace.
     *
     * @param row      The row of the starting tile
     * @param col      The column of the starting tile
     * @param curSpace The starting Boardspace
     * @return A list of boardspaces that are vertically adjacent
     */
    private ArrayList<BoardSpace> getVertWord(int row, int col, BoardSpace curSpace) {
        // Find the first boardspace that makes up the word
        while (withinBounds(row - 1, col)) {
            if (getBoardSpace(row - 1, col).hasTile()) {
                curSpace = getBoardSpace(row - 1, col);
                row = curSpace.getRow();
                col = curSpace.getCol();
            } else {
                break;
            }
        }
        ArrayList<BoardSpace> spaces = new ArrayList<>();
        spaces.add(curSpace);

        // Collect all Boardspaces that are next to each other into the list of spaces
        while (withinBounds(row + 1, col)) {
            if (getBoardSpace(row + 1, col).hasTile()) {
                curSpace = getBoardSpace(row + 1, col);
                row = curSpace.getRow();
                col = curSpace.getCol();
                spaces.add(curSpace);
            } else {
                break;
            }
        }
        return spaces;
    }

    /**
     * Finds a horizontal word created by the current placed letters, if the word
     * exists and adds it
     * to the list of words formed.
     *
     * Checks if all current tile placements form this word. If they do not, does
     * not create a word and returns
     * false.
     *
     * @return True if all placed letters form a word, false otherwise.
     */
    public boolean findHorizontalWord() {
        BoardSpace curTile = curTilePlacements.getFirst();
        int row = curTile.getRow();
        int col = curTile.getCol();

        ArrayList<BoardSpace> spaces = getHorizontalWord(row, col, curTile); // List of spaces making up word

        // Check if there is a placed tile that is missing from this list of spaces
        for (BoardSpace space : curTilePlacements) {
            // If a placed tile is missing, placement invalid
            if (!spaces.contains(space)) {
                return false;
            }
        }

        // If main word has fewer tiles than all placed tiles, return false
        // Prevents disjointed plays
        if (spaces.size() < curTilePlacements.size()) {
            return false;
        }

        // Add word to list of words
        curWords.add(new Word(spaces));
        return true;
    }

    /**
     * Finds all related vertical words formed from current tile placements.
     */
    public void findHorizontalWords() {
        int row;
        int col;
        for (BoardSpace space : curTilePlacements) {
            row = space.getRow();
            col = space.getCol();
            ArrayList<BoardSpace> spaces = getHorizontalWord(row, col, space); // List of spaces making up word

            if (spaces.size() > 1) {
                curWords.add(new Word(spaces));
            }
        }
    }

    /**
     * Extracts a list of tiles that are horizontally adjacent given a starting
     * BoardSpace.
     *
     * @param row      The row of the starting tile
     * @param col      The column of the starting tile
     * @param curSpace The starting Boardspace
     * @return A list of boardspaces that are horizontally adjacent
     */
    private ArrayList<BoardSpace> getHorizontalWord(int row, int col, BoardSpace curSpace) {
        // Find the first boardspace that makes up the word
        while (withinBounds(row, col - 1)) {
            if (getBoardSpace(row, col - 1).hasTile()) {
                curSpace = getBoardSpace(row, col - 1);
                row = curSpace.getRow();
                col = curSpace.getCol();
            } else {
                break;
            }
        }
        ArrayList<BoardSpace> spaces = new ArrayList<>();
        spaces.add(curSpace);

        // Collect all Boardspaces that are next to each other into the list of spaces
        while (withinBounds(row, col + 1)) {
            if (getBoardSpace(row, col + 1).hasTile()) {
                curSpace = getBoardSpace(row, col + 1);
                row = curSpace.getRow();
                col = curSpace.getCol();
                spaces.add(curSpace);
            } else {
                break;
            }
        }
        return spaces;
    }

    /**
     * Checks if all the currently formed words are valid words.
     *
     * @return False if no words have been formed or if at least 1 word is invalid,
     *         true otherwise
     */
    public boolean validWords() {
        if (curWords.isEmpty()) { // Return false if player placed no tiles
            return false;
        }

        for (Word word : curWords) { // Return false if at least 1 word is invalid
            if (!word.isValid())
                return false;
        }
        if (curTilePlacements.contains(getBoardSpace(7, 7))) { // If we are placing on the starting tile, return true
            return true;
        }

        for (Word word : curWords) {
            // Check if at least 1 word formed has a previously placed tile
            // Meaning the word is adjacent to at least 1 previously placed letter and is
            // valid
            if (word.hasPreviouslyPlacedTile()) {
                return true;
            }
        }

        return false; // Words invalid since tiles are not adjacent to at least 1 previously placed
                      // tile and we are not on starting space
    }

    /**
     * Clears the list of current tiles placed
     */
    public void clearCurrentPlacements() {
        curTilePlacements.clear();
    }

    /**
     * Clears list of current words in play
     */
    public void clearCurrentWords() {
        curWords.clear();
    }

    /**
     * Sets all tiles in a word to placed.
     */
    public void lockCurPlacement() {
        for (BoardSpace boardspace : curTilePlacements) {
            boardspace.getTile().placeTile();
            placedTiles.add(boardspace); // saved for AI to refer to
        }
        curTilePlacements.clear();
    }

    /**
     * Returns all placed tiles.
     * 
     * @return ArrayList of boardspaces with tiles on them
     */
    public ArrayList<BoardSpace> getPlacedTiles() {
        return placedTiles;
    }

    /**
     * Returns if placed tiles.
     * 
     * @param c being looked for
     * @return whether character is placed on the board or not
     */
    public boolean hasTilePlaced(char c) {
        for (BoardSpace boardspace : placedTiles) {
            if (boardspace.getTile().getLetter() == c)
                return true;
        }
        return false;
    }

    /**
     * Removes a tile from a boardspace given a row and column
     *
     * @param col The column of the boardspace containing the tile
     * @param row The row of the boardspace containing the tile
     *
     * @return The tile on a boardspace. Null if there is no tile
     */
    public Tile removeTile(int row, int col) {
        BoardSpace boardspace = getBoardSpace(row, col);

        if (boardspace.hasTile()) {
            if (!boardspace.getTile().isPlaced()) {
                curTilePlacements.remove(boardspace);
                return boardspace.removeTile();
            }
        }

        return null;
    }

    /**
     * Removes all currently placed tiles on the board
     *
     * @return A list of all removed tiles
     */
    public ArrayList<Tile> removeAll() {
        ArrayList<Tile> tiles = new ArrayList<>();

        for (BoardSpace boardspace : curTilePlacements) {
            tiles.add(boardspace.removeTile());
        }

        clearCurrentPlacements();
        return tiles;
    }

    /**
     * Returns the boardspace at a given position on the board.
     *
     * @param row The row of the boardspace
     * @param col The column of the boardspace
     * @return The boardspace at the specified row and column
     */
    public BoardSpace getBoardSpace(int row, int col) {
        if (row < BOARDSIZE && col < BOARDSIZE) {
            return board.get(row).get(col);
        } else {
            throw new IndexOutOfBoundsException("Cannot get space outside board size at: " + row + ", " + col + "!");
        }

    }

    /**
     * Calculates the score of words formed for this round.
     *
     * @return the score a player receives
     */
    public int calcScore() {
        int playerScore = 0;
        for (Word word : curWords) {
            playerScore += word.getWordScore();
        }

        if (curTilePlacements.size() == 7) { // Bonus score if player placed 7 tiles
            playerScore += 50;
        }
        return playerScore;
    }

    /**
     * Creates a copy of the current Board.
     *
     * @return A copy of the current Board.
     */
    public Board createCopy() {
        Board newBoard = new Board();
        newBoard.board = new ArrayList<>(15);

        // clone current board (custom compatible)
        for (int i = 0; i < this.board.size(); i++) {
            ArrayList<BoardSpace> row = new ArrayList<>();
            for (int j = 0; j < this.board.get(i).size(); j++) {
                BoardSpace newBoardSpace = new BoardSpace(this.board.get(i).get(j).getModifier());
                newBoardSpace.setRow(i);
                newBoardSpace.setCol(j);
                row.add(newBoardSpace);
            }
            newBoard.board.add(row);
        }

        // curWords = new ArrayList<>();
        for (Word word : this.curWords) {
            newBoard.curWords.add(word);
        }

        // curTilePlacements = new ArrayList<>();
        for (BoardSpace boardspace : this.placedTiles) {
            newBoard.placeTile(new Tile(boardspace.getTile().getLetter()), boardspace.getRow(), boardspace.getCol());
        }

        // placedTiles = new ArrayList<>();
        newBoard.lockCurPlacement();

        return newBoard;
    }
}
